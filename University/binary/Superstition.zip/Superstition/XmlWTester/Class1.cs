using System;
using System.Reflection;
using System.Collections;

using Microsoft.DirectX;

using XmlDataBindig;

namespace XmlWTester
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			MainClass m = new MainClass();
			m.list.Add(12);
			m.list.Add(new MainClass());
			m.m = new MainClass();
			XmlHandler.Save("test.xml", m);
			XmlHandler.Save("matrix.xml", Matrix.Identity);
			XmlHandler.Save("int.xml", 27);

			int iresult = (int)XmlHandler.Load("int.xml");
			Matrix mresult = (Matrix)XmlHandler.Load("matrix.xml");
			MainClass l = (MainClass)XmlHandler.Load("test.xml");
			XmlHandler.Save("result.xml", l);

			Type test = Type.GetType("Microsoft.DirectX.Matrix[]");

			Console.WriteLine("-- vege --");
		}
	}

	public class MainClass
	{
		public int integer = 12;
		public ArrayList list;
		public Vector3[] vectors;
		public Vector3 v;
		public MainClass m;

		public MainClass()
		{
			m = null;
			list = new ArrayList();
			vectors = new Vector3[2];
			vectors[0] = new Vector3(0f, 0f, 0f);
			vectors[1] = new Vector3(1f, 1f, 1f);
		}
	}

}
