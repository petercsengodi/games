using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using FileOperations;

namespace XmlTester
{
	/// <summary>
	/// Summary description for XmlTester.
	/// </summary>
	public class XmlTester : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.PropertyGrid pgrid;

		public XmlTester()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			control = new FileControl(
				"XML files (*.xml)|*.xml|All Files (*.*)|*.*",
				@"..\..\", new FileOperation(LoadFile),
				new FileOperation(SaveFile));
		}

		protected FileControl control;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pgrid = new System.Windows.Forms.PropertyGrid();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// pgrid
			// 
			this.pgrid.CommandsVisibleIfAvailable = true;
			this.pgrid.Dock = System.Windows.Forms.DockStyle.Right;
			this.pgrid.LargeButtons = false;
			this.pgrid.LineColor = System.Drawing.SystemColors.ScrollBar;
			this.pgrid.Location = new System.Drawing.Point(320, 0);
			this.pgrid.Name = "pgrid";
			this.pgrid.Size = new System.Drawing.Size(224, 326);
			this.pgrid.TabIndex = 0;
			this.pgrid.Text = "PropertyGrid";
			this.pgrid.ViewBackColor = System.Drawing.SystemColors.Window;
			this.pgrid.ViewForeColor = System.Drawing.SystemColors.WindowText;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem4,
																					  this.menuItem5});
			this.menuItem1.Text = "File";
			this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "New";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.Text = "Open";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 2;
			this.menuItem4.Text = "Save";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 3;
			this.menuItem5.Text = "Exit";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// XmlTester
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(544, 326);
			this.Controls.Add(this.pgrid);
			this.Menu = this.mainMenu1;
			this.Name = "XmlTester";
			this.Text = "XmlTester";
			this.Load += new System.EventHandler(this.XmlTester_Load);
			this.ResumeLayout(false);

		}
		#endregion

	
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new XmlTester());
		}

		private void XmlTester_Load(object sender, System.EventArgs e)
		{
		
		}

		// New
		private void menuItem1_Click(object sender, System.EventArgs e)
		{
			control.New();
		}

		// Open
		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			control.Open();
		}

		// Save
		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			control.Save();
		}

		// Exit
		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			control.Save();
			Close();
		}

		public void LoadFile(string file)
		{
//			pgrid.SelectedObject = XmlDataBindig.XmlHandler.Load(
//				file, "XmlTester");
		}

		public void SaveFile(string file)
		{
		}

	}


}
