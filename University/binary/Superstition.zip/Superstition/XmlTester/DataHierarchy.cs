using System;
using System.Collections;

namespace XmlTester
{

	public class DataRoot
	{
		private string _name;
		public String name
		{
			get { return _name; }
			set { _name = value; }
		}

		private int _sx;
		public int sx
		{
			get { return _sx; }
			set { _sx = value; }
		}

		private ArrayList _renders;
		public ArrayList children_render()
		{
			return _renders;
		}

		private int _size;
		public int size
		{
			get { return _size; }
			set { _size = value; }
		}

		public DataRoot()
		{
			_renders = new ArrayList();
		}

	} // End of class Data Root


	public class render
	{


		private string _name;
		public string name
		{
			get { return _name; }
			set { _name = value; }
		}
	} // End of class render



}
