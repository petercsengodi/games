using System;
using System.IO;
using System.Xml;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ScheduleReport
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Report : System.Windows.Forms.Form
	{
		private System.Windows.Forms.CheckBox checkedSchedule;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label itemLabel;
		private System.Windows.Forms.ColumnHeader Item;
		private System.Windows.Forms.ColumnHeader CheckedItem;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ListView itemList;
		private System.Windows.Forms.RichTextBox solutionText;

		private DirectoryInfo actual = null, html, root;
		private DirectoryInfo[] versions;
		private FileInfo[] picts, downloads;
		private System.Windows.Forms.ColumnHeader Files;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.RichTextBox descriptionText;
		private System.Windows.Forms.Button generate;
		private System.Windows.Forms.ListView downloadList;
		private System.Windows.Forms.ComboBox shots;
		private FileInfo ini_xml;
		private DrawPanel drawPanel;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox dateBox;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox title;

		public Report()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			Directory.SetCurrentDirectory(@"..\..\..\..\Documentation");
			versions = new DirectoryInfo("versions").GetDirectories();
			html = new DirectoryInfo("html");
			root = new DirectoryInfo(".");

			for(int i = versions.Length - 1; i >= 0; i--)
			{
				itemList.Items.Add( new ListViewItem(
					new string[]{ versions[i].Name, "false" } ));
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
//				if (components != null) 
//				{
//					components.Dispose();
//				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.checkedSchedule = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.itemLabel = new System.Windows.Forms.Label();
			this.itemList = new System.Windows.Forms.ListView();
			this.Item = new System.Windows.Forms.ColumnHeader();
			this.CheckedItem = new System.Windows.Forms.ColumnHeader();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.descriptionText = new System.Windows.Forms.RichTextBox();
			this.solutionText = new System.Windows.Forms.RichTextBox();
			this.downloadList = new System.Windows.Forms.ListView();
			this.Files = new System.Windows.Forms.ColumnHeader();
			this.label4 = new System.Windows.Forms.Label();
			this.generate = new System.Windows.Forms.Button();
			this.shots = new System.Windows.Forms.ComboBox();
			this.drawPanel = new ScheduleReport.DrawPanel();
			this.label5 = new System.Windows.Forms.Label();
			this.dateBox = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.title = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// checkedSchedule
			// 
			this.checkedSchedule.Location = new System.Drawing.Point(320, 40);
			this.checkedSchedule.Name = "checkedSchedule";
			this.checkedSchedule.Size = new System.Drawing.Size(80, 16);
			this.checkedSchedule.TabIndex = 1;
			this.checkedSchedule.Text = "Check item";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(216, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Actual Item:";
			// 
			// itemLabel
			// 
			this.itemLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.itemLabel.Location = new System.Drawing.Point(216, 64);
			this.itemLabel.Name = "itemLabel";
			this.itemLabel.Size = new System.Drawing.Size(184, 24);
			this.itemLabel.TabIndex = 3;
			this.itemLabel.Text = "<Empty>";
			// 
			// itemList
			// 
			this.itemList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																					   this.Item,
																					   this.CheckedItem});
			this.itemList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.itemList.Location = new System.Drawing.Point(8, 8);
			this.itemList.Name = "itemList";
			this.itemList.Size = new System.Drawing.Size(192, 120);
			this.itemList.Sorting = System.Windows.Forms.SortOrder.Descending;
			this.itemList.TabIndex = 4;
			this.itemList.View = System.Windows.Forms.View.Details;
			this.itemList.SelectedIndexChanged += new System.EventHandler(this.itemList_SelectedIndexChanged);
			// 
			// Item
			// 
			this.Item.Text = "Items";
			this.Item.Width = 131;
			// 
			// CheckedItem
			// 
			this.CheckedItem.Text = "Checked";
			this.CheckedItem.Width = 56;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 184);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(136, 24);
			this.label2.TabIndex = 5;
			this.label2.Text = "Description:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(200, 184);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(168, 24);
			this.label3.TabIndex = 6;
			this.label3.Text = "Solution:";
			// 
			// descriptionText
			// 
			this.descriptionText.Location = new System.Drawing.Point(8, 216);
			this.descriptionText.Name = "descriptionText";
			this.descriptionText.Size = new System.Drawing.Size(176, 152);
			this.descriptionText.TabIndex = 7;
			this.descriptionText.Text = "descriptionText";
			// 
			// solutionText
			// 
			this.solutionText.Location = new System.Drawing.Point(200, 216);
			this.solutionText.Name = "solutionText";
			this.solutionText.Size = new System.Drawing.Size(256, 152);
			this.solutionText.TabIndex = 8;
			this.solutionText.Text = "solutionText";
			// 
			// downloadList
			// 
			this.downloadList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						   this.Files});
			this.downloadList.Location = new System.Drawing.Point(472, 216);
			this.downloadList.Name = "downloadList";
			this.downloadList.Size = new System.Drawing.Size(176, 152);
			this.downloadList.TabIndex = 10;
			this.downloadList.View = System.Windows.Forms.View.List;
			// 
			// Files
			// 
			this.Files.Text = "files";
			this.Files.Width = 165;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(472, 184);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(160, 24);
			this.label4.TabIndex = 11;
			this.label4.Text = "Downloads:";
			// 
			// generate
			// 
			this.generate.Location = new System.Drawing.Point(8, 136);
			this.generate.Name = "generate";
			this.generate.Size = new System.Drawing.Size(192, 24);
			this.generate.TabIndex = 12;
			this.generate.Text = "Generate Report";
			this.generate.Click += new System.EventHandler(this.generate_Click);
			// 
			// shots
			// 
			this.shots.Location = new System.Drawing.Point(216, 8);
			this.shots.Name = "shots";
			this.shots.Size = new System.Drawing.Size(176, 21);
			this.shots.TabIndex = 13;
			this.shots.Text = "Screen Shots";
			this.shots.SelectedIndexChanged += new System.EventHandler(this.shots_SelectedIndexChanged);
			// 
			// drawPanel
			// 
			this.drawPanel.Location = new System.Drawing.Point(416, 8);
			this.drawPanel.Name = "drawPanel";
			this.drawPanel.Picture = null;
			this.drawPanel.Size = new System.Drawing.Size(232, 144);
			this.drawPanel.TabIndex = 14;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(208, 136);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(40, 24);
			this.label5.TabIndex = 15;
			this.label5.Text = "Date:";
			// 
			// dateBox
			// 
			this.dateBox.Location = new System.Drawing.Point(256, 136);
			this.dateBox.Name = "dateBox";
			this.dateBox.Size = new System.Drawing.Size(144, 20);
			this.dateBox.TabIndex = 16;
			this.dateBox.Text = "";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(208, 104);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(40, 24);
			this.label6.TabIndex = 17;
			this.label6.Text = "Title:";
			// 
			// title
			// 
			this.title.Location = new System.Drawing.Point(256, 104);
			this.title.Name = "title";
			this.title.Size = new System.Drawing.Size(144, 20);
			this.title.TabIndex = 18;
			this.title.Text = "";
			// 
			// Report
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(656, 382);
			this.Controls.Add(this.title);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.dateBox);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.drawPanel);
			this.Controls.Add(this.shots);
			this.Controls.Add(this.generate);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.downloadList);
			this.Controls.Add(this.solutionText);
			this.Controls.Add(this.descriptionText);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.itemList);
			this.Controls.Add(this.itemLabel);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.checkedSchedule);
			this.Name = "Report";
			this.Text = "Schedule Report";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.Report_Closing);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Report());
		}

		private void itemList_SelectedIndexChanged(object sender, System.EventArgs e)
		{

			if(actual != null)
			{
				SaveActualItem();
			}

			ListView _sender = (ListView)sender;
			if(_sender.SelectedIndices.Count == 0) return;
			string file = _sender.SelectedItems[0].SubItems[0].Text;
			actual = new DirectoryInfo("versions\\" + file);
			picts = actual.GetFiles("*.jpg");
			downloads = actual.GetFiles("*.zip");

			try
			{
				ini_xml = actual.GetFiles("ini.xml")[0];
				XmlDocument doc = new XmlDocument();
				doc.Load(ini_xml.FullName);
				XmlNode root = doc.FirstChild;
				descriptionText.Text = root.SelectNodes("Description")[0].InnerText;
				solutionText.Text = root.SelectNodes("Solution")[0].InnerText;
				if(root.SelectNodes("Checked")[0].InnerText.Equals("true"))
					checkedSchedule.CheckState = CheckState.Checked;
				else checkedSchedule.CheckState = CheckState.Unchecked;
				title.Text = root.SelectNodes("Title")[0].InnerText;
				dateBox.Text = root.SelectNodes("Date")[0].InnerText;
			} 
			catch (Exception)
			{
				ini_xml = null;
				title.Text = null;
				dateBox.Text = null;
				solutionText.Text = "";
				descriptionText.Text = "";
				checkedSchedule.CheckState = CheckState.Unchecked;
			}

			itemLabel.Text = actual.Name;

			downloadList.Items.Clear();
			for(int i = 0; i < downloads.Length; i++)
			{
				downloadList.Items.Add(new ListViewItem(downloads[i].Name));
			}

			shots.Items.Clear();
			for(int i = 0; i < picts.Length; i++)
			{
				shots.Items.Add(picts[i].Name);
			}
		}

		private void shots_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ComboBox _sender = (ComboBox) sender;
			string text = (string)_sender.SelectedItem;
			drawPanel.Picture = Image.FromFile(actual.GetFiles(text)[0].FullName);
			drawPanel.Invalidate();
		}
	
		public void SaveActualItem()
		{
			if(actual == null) return;

			XmlDocument doc = new XmlDocument();
			XmlNode root = doc.CreateElement("root");
	 		doc.AppendChild(root);

			XmlNode 
				Title = doc.CreateElement("Title"),
				Date = doc.CreateElement("Date"),
				Description = doc.CreateElement("Description"),
				Solution = doc.CreateElement("Solution"),
				Checked = doc.CreateElement("Checked");

			Title.InnerText = title.Text;
			root.AppendChild(Title);

			Date.InnerText = dateBox.Text;
			root.AppendChild(Date);

			Description.InnerText = descriptionText.Text;
			root.AppendChild(Description);

			Solution.InnerText = solutionText.Text;
			root.AppendChild(Solution);

			if(checkedSchedule.CheckState == CheckState.Checked)
				Checked.InnerText = "true";
			else Checked.InnerText = "false";
			root.AppendChild(Checked);

			doc.Save("versions\\" + actual.Name + "\\ini.xml");

			actual = null;
		}

		private void Report_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			SaveActualItem();
		}

		private void generate_Click(object sender, System.EventArgs e)
		{
			SaveActualItem();
			GenerateWebSite();
			for(int i = versions.Length - 1; i >= 0; i--)
		{
				GenerateVersionSite(versions[i]);
			}
		}

		private void GenerateWebSite()
		{
			XmlDocument WebSite = new XmlDocument();
			XmlElement html = GenerateHtml(WebSite, 
				"Cseng�di P�ter - �n�ll� laborat�rium, 9. f�l�v");
		
			TableResult hallgato = GenerateTable(WebSite, html, 2, 6, false, true);
			GenerateFont(WebSite, hallgato.Caption, "Arial Black", 5).InnerText = "Hallgat� adatai";
            hallgato.VerticalHeaders[0].InnerText = "N�v"; hallgato.Cells[0, 0].InnerText = "Cseng�di P�ter";
			hallgato.VerticalHeaders[1].InnerText = "Neptun"; hallgato.Cells[0, 1].InnerText = "JOT2FY";
			hallgato.VerticalHeaders[2].InnerText = "�vfolyam"; hallgato.Cells[0, 2].InnerText = "5.";
			hallgato.VerticalHeaders[3].InnerText = "Szak"; hallgato.Cells[0, 3].InnerText = "M�szaki Informatika Szak";
			hallgato.VerticalHeaders[4].InnerText = "Kar"; 
			GenerateLink(WebSite, hallgato.Cells[0, 4], "http://www.vdk.bme.hu", 
				"new_window").InnerText = "Villamosm�rn�ki �s Informatikai Kar";
			hallgato.VerticalHeaders[5].InnerText = "Egyetem";
			GenerateLink(WebSite, hallgato.Cells[0, 5], "http://www.bme.hu", 
				"new_window").InnerText = "Budapesti M�szaki �s Gazdas�gtudom�nyi Egyetem";

			html.AppendChild(WebSite.CreateElement("br"));
			html.AppendChild(WebSite.CreateElement("br"));

			TableResult konzulens = GenerateTable(WebSite, html, 2, 3, false, true);
			GenerateFont(WebSite, konzulens.Caption, "Arial Black", 5).InnerText = "Konzulens adatai";
			konzulens.VerticalHeaders[0].InnerText = "N�v"; konzulens.Cells[0, 0].InnerText = "Albert Istv�n";
			konzulens.VerticalHeaders[1].InnerText = "Tansz�k";
			GenerateLink(WebSite, konzulens.Cells[0, 1], "http://www.aut.bme.hu", 
				"new_window").InnerText = "Automatiz�l�si �s Alkalmazott Informatika Tansz�k";
			konzulens.VerticalHeaders[2].InnerText = "Egyetem";
			GenerateLink(WebSite, konzulens.Cells[0, 2], "http://www.bme.hu", 
				"new_window").InnerText = "Budapesti M�szaki �s Gazdas�gtudom�nyi Egyetem";


			html.AppendChild(WebSite.CreateElement("br"));
			html.AppendChild(WebSite.CreateElement("br"));

			TableResult labor = GenerateTable(WebSite, html, 2, 4, false, true);
			GenerateFont(WebSite, labor.Caption, "Arial Black", 5).InnerText = "Labor munka adatai";
			labor.VerticalHeaders[0].InnerText = "T�ma"; labor.Cells[0, 0].InnerText = "Multim�di�s szoftver fejleszt�se .Net platformon";
			labor.VerticalHeaders[1].InnerText = "Platform"; 
			GenerateLink(WebSite, labor.Cells[0, 1], "http://msdn.microsoft.com/vstudio/productinfo/trial/default.aspx", 
				"new_window").InnerText = "Microsoft Visual Studio .Net 2003";
			labor.VerticalHeaders[2].InnerText = "Megjelen�t�s"; 
			GenerateLink(WebSite, labor.Cells[0, 2], "http://www.microsoft.com/downloads/details.aspx?FamilyID=fd044a42-9912-42a3-9a9e-d857199f888e&displaylang=en", 
				"new_window").InnerText = "Microsoft DirectX 9.0 Summer version 2004";
			labor.VerticalHeaders[3].InnerText = "R�vid le�r�s"; labor.Cells[0, 3].InnerText = "FPS jelleg� j�t�k v�letlenszer�en gener�lt szintekkel.";


			html.AppendChild(WebSite.CreateElement("br"));
			html.AppendChild(WebSite.CreateElement("br"));
			html.AppendChild(WebSite.CreateElement("br"));

			TableResult table = GenerateTable(WebSite, html, 4, versions.Length, true, false);
			GenerateFont(WebSite, table.Caption, "Arial Black", 6).InnerText = "Tervezett �temez�s";
			
			table.HorizontalHeaders[0].InnerText = "Hat�rid�";
			table.HorizontalHeaders[1].InnerText = "Feladat";
			table.HorizontalHeaders[2].InnerText = "Befejez�s";
			table.HorizontalHeaders[3].InnerText = "";

//			for(int i = versions.Length - 1; i >= 0; i--)
			for(int i = 0; i < versions.Length; i++)
		{
				XmlDocument version = new XmlDocument();
				version.Load("versions\\" + versions[i].Name + "\\ini.xml");
				
				table.Cells[0, i].InnerText = GetAttribute(version, "Date");
				table.Cells[1, i].InnerText = GetAttribute(version, "Title");
				if(GetAttribute(version, "Checked").Equals("true")) table.Cells[2, i].InnerText = "Beadva";
				else table.Cells[2, i].InnerText = "Nincs k�sz";
				GenerateLink(WebSite, table.Cells[3, i], "html/" + versions[i].Name + ".htm").InnerText = "B�vebben";
			}

			WebSite.Save("index.html");
		}

		private void GenerateVersionSite(DirectoryInfo version)
		{
			TableResult result;
			XmlElement link, font, align;

			XmlDocument VSite = new XmlDocument();
			XmlElement html = GenerateHtml(VSite, "Cseng�di P�ter - �n�ll� laborat�rium, 9. f�l�v : " + version.Name);

			XmlDocument v = new XmlDocument();
			v.Load("versions\\" + version.Name + "\\ini.xml");

			align = GenerateAlign(VSite, html, "center");
			font = GenerateFont(VSite, align, "Arial", 6);
			font.InnerText = "Feladat : " + GetAttribute(v, "Title");
			align = GenerateAlign(VSite, html, "center");
			font = GenerateFont(VSite, align, "Arial", 6);
			font.InnerText = "Hat�rid� : " + GetAttribute(v, "Date");

			align = GenerateAlign(VSite, html, "center");
			font = GenerateFont(VSite, align, "Arial", 6);
			if(GetAttribute(v, "Checked").Equals("true"))
			{
				font.InnerText = "Befejez�s : " + "Beadva";			
			} 
			else 
			{
				font.InnerText = "Befejez�s : " + "Nincs k�sz";			
			}

			html = GenerateAlign(VSite, html, "center");

			html.AppendChild(VSite.CreateElement("br"));
			html.AppendChild(VSite.CreateElement("br"));

			result = GenerateTable(VSite, html, 2, 1, true, false);
			result.HorizontalHeaders[0].InnerText = "Le�r�s";
			result.HorizontalHeaders[1].InnerText = "Megold�s";
			result.Cells[0, 0].InnerText = GetAttribute(v, "Description");
			result.Cells[1, 0].InnerText = GetAttribute(v, "Solution");

			html.AppendChild(VSite.CreateElement("br"));
			html.AppendChild(VSite.CreateElement("br"));

			FileInfo[] d = version.GetFiles("*.zip");
			FileInfo[] s = version.GetFiles("*.jpg");

			result = GenerateTable(VSite, html, 1, s.Length, false, false);
			font = GenerateFont(VSite, result.Caption, "Times New Roman", 4);
			font.InnerText = "K�pek";
			for(int i = 0; i < s.Length; i++)
			{
				link = GenerateLink(VSite, result.Cells[0, i], 
					"..\\versions\\" + version.Name + "\\" + s[i].Name, "new_window2");
				link.InnerText = s[i].Name;
			}

			html.AppendChild(VSite.CreateElement("br"));
			html.AppendChild(VSite.CreateElement("br"));

			result = GenerateTable(VSite, html, 1, d.Length, false, false);
			font = GenerateFont(VSite, result.Caption, "Times New Roman", 4);
			font.InnerText = "Let�lthet� �llom�nyok.";
			for(int i = 0; i < d.Length; i++){
				link = GenerateLink(VSite, result.Cells[0, i], 
					"..\\versions\\" + version.Name + "\\" + d[i].Name, "new_window1");
				link.InnerText = d[i].Name;
			}

			html.AppendChild(VSite.CreateElement("br"));
			html.AppendChild(VSite.CreateElement("br"));

			link = GenerateLink(VSite, html, "..\\index.html");
			link.InnerText = "Vissza a f�oldalra";

			VSite.Save("html\\" + version.Name + ".htm");
		}
		
		private XmlElement GenerateAlign(XmlDocument doc, XmlElement root, string align)
		{
			XmlElement ret = doc.CreateElement("div");
			ret.SetAttribute("align", align);
			root.AppendChild(ret);
			return ret;
		}

		private void GenerateBreak(XmlDocument doc, XmlElement root)
		{
			root.AppendChild(doc.CreateElement("br"));
		}

		private string GetAttribute(XmlDocument doc, string attribute)
		{
			XmlNodeList attrs = doc.FirstChild.SelectNodes(attribute);
			if((attrs == null) || (attrs[0] == null)) return "";
			return attrs[0].InnerText;
		}

		private XmlElement GenerateFont(XmlDocument doc, XmlElement root, 
			string type, int size)
		{
			XmlElement ret = doc.CreateElement("font");
			root.AppendChild(ret);
			ret.SetAttribute("type", type);
			ret.SetAttribute("size", size.ToString());
			return ret;
		}

		private XmlElement GenerateFont(XmlDocument doc, XmlElement root, 
			string type, int size, string color)
		{
			XmlElement ret = doc.CreateElement("font");
			root.AppendChild(ret);
			ret.SetAttribute("type", type);
			ret.SetAttribute("size", size.ToString());
			ret.SetAttribute("color", color);
			return ret;
		}

		private TableResult GenerateTable(XmlDocument doc, XmlElement root, 
			int xsize, int ysize, bool horizontalHeader, bool verticalHeader)
		{
			TableResult ret = new TableResult();

			XmlElement table = doc.CreateElement("table");
			table.SetAttribute("border", "3");
			root.AppendChild(table);
			ret.Caption = doc.CreateElement("caption");
			table.AppendChild(ret.Caption);
			int k = verticalHeader?1:0, l = horizontalHeader?1:0;
			ret.Cells = new XmlElement[xsize, ysize];
			ret.HorizontalHeaders = new XmlElement[xsize];
			ret.VerticalHeaders = new XmlElement[ysize];

			for(int i = 0; i < xsize; i++) ret.HorizontalHeaders[i] = doc.CreateElement("th");
			for(int i = 0; i < ysize; i++) ret.VerticalHeaders[i] = doc.CreateElement("td");
			for(int i = 0; i < xsize; i++)
			{
				for(int j = 0; j < ysize; j++)
				{
					ret.Cells[i,j] = doc.CreateElement("td");
				}
			}

			XmlElement row = doc.CreateElement("tr");
			table.AppendChild(row);
			if(horizontalHeader && verticalHeader) row.AppendChild(doc.CreateElement("td"));
			if(horizontalHeader) for(int i = 0; i < xsize; i++) 
									 row.AppendChild(ret.HorizontalHeaders[i]);

			for(int j = 0; j < ysize; j++)
			{
				row = doc.CreateElement("tr");
				table.AppendChild(row);
				if(verticalHeader) row.AppendChild(ret.VerticalHeaders[j]);
				for(int i = 0; i < xsize; i++)
				{
					row.AppendChild(ret.Cells[i, j]);
				}
			}

			XmlElement font;

			if(verticalHeader)
			{
				XmlElement b;
				for(int i = 0; i < ysize; i++)
				{
					ret.VerticalHeaders[i].SetAttribute("bgcolor", PROPERTIES.HEADER_BACKGROUND);
					b = doc.CreateElement("b");
					ret.VerticalHeaders[i].AppendChild(b);
					font = GenerateFont(doc, b, "Arial", 3, PROPERTIES.HEADER_FOREGROUND);
					ret.VerticalHeaders[i] = font;
				}
			}

			if(horizontalHeader)
			{
				for(int i = 0; i < xsize; i++)
				{
					ret.HorizontalHeaders[i].SetAttribute("bgcolor", PROPERTIES.HEADER_BACKGROUND);
					font = GenerateFont(doc, ret.HorizontalHeaders[i], "Arial", 3, PROPERTIES.HEADER_FOREGROUND);
					ret.HorizontalHeaders[i] = font;
				}
			}

			for(int i = 0; i < xsize; i++)
			{
				for(int j = 0; j < ysize; j++)
				{
					ret.Cells[i,j].SetAttribute("bgcolor", PROPERTIES.CELL_BACKGROUND);
					font = GenerateFont(doc, ret.Cells[i,j], "Arial", 3, PROPERTIES.CELL_FOREGROUND);
					ret.Cells[i, j] = font;
				}
			}

			font = GenerateFont(doc, ret.Caption, "Arial", 4, PROPERTIES.CAPTION_FOREGROUND);
			ret.Caption = font;

			return ret;
		}

		private XmlElement GenerateLink(XmlDocument doc, XmlElement root, string link)
		{
			XmlElement ret = doc.CreateElement("a");
			root.AppendChild(ret);
			ret.SetAttribute("href", link);

			ret = GenerateFont(doc, ret, "Verdana", 3, PROPERTIES.LINK);

			return ret;
		}

		private XmlElement GenerateLink(XmlDocument doc, XmlElement root, 
			string link, string target)
		{
			XmlElement ret = doc.CreateElement("a");
			root.AppendChild(ret);
			ret.SetAttribute("href", link);
			ret.SetAttribute("target", target);

			ret = GenerateFont(doc, ret, "Verdana", 3, PROPERTIES.LINK);
			
			return ret;
		}

		private XmlElement GenerateImage(XmlDocument doc, XmlElement root, string file)
		{
			XmlElement img = doc.CreateElement("img");
			root.AppendChild(img);
			img.SetAttribute("src", file);
			return img;
		}

		enum Divide{ Horizontal, Vertical };

		private FrameResult GenerateFrames(XmlDocument doc, XmlElement root,
			Divide div, int size1, string name1, int size2, string name2)
		{
			FrameResult ret = new FrameResult();
			XmlElement frameset = doc.CreateElement("frameset");
			root.AppendChild(frameset);
			root.AppendChild(doc.CreateElement("noframes"));
			
			string temp = ",";
			if(size1 == 0) temp = "*" + temp; else temp = size1.ToString() + temp;
			if(size2 == 0) temp = temp + "*"; else temp = temp = size2.ToString();

			if(div == Divide.Horizontal) root.SetAttribute("cols", temp);
			else root.SetAttribute("rows", temp);
			frameset.SetAttribute("border", "0");
			XmlElement frame1 = doc.CreateElement("frame");
			frameset.AppendChild(frame1);
			XmlElement frame2 = doc.CreateElement("frame");
			frameset.AppendChild(frame2);

			frame1.SetAttribute("name", name1);
			frame1.SetAttribute("src", name1 + ".htm");
			frame1.SetAttribute("marginheight", "0");
			frame1.SetAttribute("marginwidth", "0");
			frame1.SetAttribute("scrolling", "0");
			frame1.SetAttribute("noresize", "");

			frame2.SetAttribute("name", name2);
			frame2.SetAttribute("src", name2 + ".htm");
			frame2.SetAttribute("marginheight", "0");
			frame2.SetAttribute("marginwidth", "0");
			frame2.SetAttribute("scrolling", "0");
			frame2.SetAttribute("noresize", "");

			ret.Frame1Doc = new XmlDocument();
			ret.Frame1Root = GenerateHtml(ret.Frame1Doc, "");
			ret.File1 = name1 + ".htm";
			ret.Frame2Doc = new XmlDocument();
			ret.Frame2Root = GenerateHtml(ret.Frame2Doc, "");
			ret.File2 = name2 + ".htm";

			return ret;
		}

		private XmlElement GenerateHtml(XmlDocument doc, string title)
		{
			XmlElement root, head, _title, body;
			
			root = doc.CreateElement("html");
			doc.AppendChild(root);

			head = doc.CreateElement("head");
			root.AppendChild(head);
			
			XmlElement meta;
			meta = doc.CreateElement("meta");
			head.AppendChild(meta);
			meta.SetAttribute("http-equiv", "Content-Type");
			meta.SetAttribute("content", "text/html; charset=UTF-8");

			_title = doc.CreateElement("title");
			head.AppendChild(_title);
			_title.InnerText = title;

			body = doc.CreateElement("body");
			body.SetAttribute("bgcolor", PROPERTIES.BACKGROUND);
			root.AppendChild(body);

			XmlElement p = doc.CreateElement("p");
			p.SetAttribute("align", "center");
			body.AppendChild(p);

			XmlElement font = doc.CreateElement("font");
			font.SetAttribute("color", PROPERTIES.FOREGROUND);
			p.AppendChild(font);

			return font;
		}
	}

	class DrawPanel : Panel
	{
		protected Image image;

		public Image Picture
		{
			get { return image; }
			set { image = value; }
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			if(image == null) e.Graphics.Clear(Color.FromArgb(0, 0, 0));
			else e.Graphics.DrawImage(image, 
					 new Rectangle(0, 0, this.Bounds.Width, this.Bounds.Height), 
					 0, 0, image.Width, image.Height, GraphicsUnit.Pixel);
		}

	}

	struct TableResult
	{
		public XmlElement Caption;
		public XmlElement[] HorizontalHeaders;
		public XmlElement[] VerticalHeaders;
		public XmlElement[,] Cells;
	}

	struct FrameResult
	{
		public XmlDocument Frame1Doc, Frame2Doc;
		public XmlElement Frame1Root, Frame2Root;
		public string File1, File2;

		public void writeFiles()
		{
			Frame1Doc.Save(File1);
			Frame2Doc.Save(File2);
		}
	}

	class PROPERTIES
	{
		public static string BACKGROUND = "#CC8000";
		public static string FOREGROUND = "#000000";
		public static string LINK = "#FFFF40";

		public static string CAPTION_FOREGROUND = "#AF0000";

		public static string HEADER_BACKGROUND = "#FFC080";
		public static string HEADER_FOREGROUND = "#000000";

		public static string CELL_BACKGROUND = "#ECA060";
		public static string CELL_FOREGROUND = "#000000";
	}
}
