using System;
using System.Windows.Forms;

namespace StoryGenerator
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class PanelDrawer : Panel
	{
		public PanelDrawer()
		{
		}

		protected override void OnPaintBackground(PaintEventArgs pevent)
		{
		}

	}
}
