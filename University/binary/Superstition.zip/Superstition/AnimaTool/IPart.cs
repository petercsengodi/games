using Microsoft.DirectX;

namespace AnimaTool
{
	interface IPart
	{
		void move(Vector3 direction, int scene);
	}
}