using System;

using Microsoft.DirectX;

using GameLib;

namespace AnimaTool
{
	/// <summary>
	/// Summary description for CPart.
	/// </summary>
	public class CPart : IPart
	{
		public CConnection[] connections;
		public Vector3[] center_point;
		
		public string mesh_file;

		public MeshID mesh;
		public Matrix[] model_transform;

		public MeshID GetMesh()
		{
			return mesh;
		}

		public void SetMesh(MeshID mesh)
		{
			this.mesh = mesh;
		}

		public CPart(CModel model)
		{
			mesh = null;
			model_transform = new Matrix[model.max_scenes];
			center_point = new Vector3[model.max_scenes];

			for(int i = 0; i < model.max_scenes; i++)
			{
				model_transform[i] = Matrix.Identity;
				center_point[i] = new Vector3(0f, 0f, 0f);
			}

			connections = new CConnection[0];
		}

		private CPart()
		{
			mesh = null;
			model_transform = new Matrix[0];
			center_point = new Vector3[0];
			connections = new CConnection[0];
		}

		#region IPart Members

		public void move(Vector3 direction, int scene)
		{
			center_point[scene] += direction;
		}
		
		#endregion

		public override string ToString()
		{
			if(mesh_file == null) return "<empty>";
			else return mesh_file;
		}

		public CPart(CPartData data)
		{
			this.mesh_file = data.mesh_file;
			this.model_transform = data.model_transform;
			this.center_point = data.center_point;
			this.connections = data.connections;
			this.mesh = MeshLibrary.Instance().LoadMesh(this.mesh_file);
		}

		public CPartData GetPartData()
		{
			CPartData ret = new CPartData();
			ret.mesh_file = this.mesh_file;
			ret.model_transform = this.model_transform;
			ret.center_point = this.center_point;
			ret.connections = this.connections;
			return ret;
		}
	}

}
