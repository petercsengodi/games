using System;
using System.Xml;
using System.Threading;
using System.Reflection;

using System.Collections;

namespace XmlDataBindig
{
	/// <summary>
	/// Summary description for XmlLoader.
	/// </summary>
	abstract public class XmlHandler
	{
		public static string Description = "Xml Data Binder";
		public static string Version = "0.5.0000";

		public static object Load(string filename)
		{
			XmlDocument document = new XmlDocument();
			document.Load(filename);
			AssemblyDomain domain = new AssemblyDomain();
			XmlNode meta = document.FirstChild;
			return LoadNode(domain, meta.FirstChild, null);
		}

		private static object LoadNode(AssemblyDomain domain,
			XmlNode root, Type member)
		{
			Type type;
			object ret = null;
			if(member != null) type = member;
			else type = domain.GetType(root.Name);

			try
			{
				if(type.IsPrimitive)
				{
					// int, float, double, ...
					MethodInfo m = type.GetMethod("Parse", 
						new Type[]{ typeof(string) });
					ret =  m.Invoke(null, 
						new object[]{root.InnerText});
				} 
				else if(type.IsEnum)
				{
					// enumeration // TODO
				} 
				else if(type.IsValueType)
				{
					// for Vector2, Vector3, Vector4, Matrix
					// for self-made stuctures

					ConstructorInfo ctor = type.GetConstructor(
						Type.EmptyTypes);
					ret = ctor.Invoke(null);

					FieldInfo[] fields = type.GetFields();
					foreach(FieldInfo field in fields)
					{
						if(field.IsStatic) continue;
						XmlNodeList list = root.SelectNodes(field.Name);
						if(list == null || list.Count != 1) continue;
						field.SetValue(ret, LoadNode(domain,
							list[0], field.FieldType));
					}
				}


				if(type.Equals(typeof(string)))
				{
					ret = root.InnerText;
				}
				else if(type.IsArray)
				{
					// arrays
					XmlNodeList children = root.ChildNodes;
					ConstructorInfo ctor = type.GetConstructor(
						new Type[]{typeof(int)});
					ret = ctor.Invoke(new object[]{children.Count});

					Array array = ret as Array;
					for(int i = 0; i < array.Length; i++)
					{
						array.SetValue(LoadNode(domain,
							children[i], null), i);
					}
				} 
				else if(type.Equals(typeof(ArrayList)))
				{
					XmlNodeList children = root.ChildNodes;
					ConstructorInfo ctor = type.GetConstructor(
						Type.EmptyTypes);
					ret = ctor.Invoke(null);

					ArrayList list = ret as ArrayList;
					for(int i = 0; i < children.Count; i++)
					{
						list.Add(LoadNode(domain, children[i], null));
					}
				}
				else if(type.IsClass)
				{
					if(member != null)
					{
						XmlNodeList list = root.ChildNodes;
						if(list != null && list.Count ==1)
						{
							ret = LoadNode(domain, list[0], null);
						}
					} 
					else
					{
						ConstructorInfo ctor = type.GetConstructor(
							Type.EmptyTypes);
						ret = ctor.Invoke(null);

						PropertyInfo[] properties = type.GetProperties();
						foreach(PropertyInfo property in properties)
						{
							XmlNodeList list = root.SelectNodes(property.Name);
							if(list == null || list.Count != 1) continue;
							property.SetValue(ret, LoadNode(domain,
								list[0], property.PropertyType), null);
						}

						FieldInfo[] fields = type.GetFields();
						foreach(FieldInfo field in fields)
						{
							if(field.IsStatic) continue;
							XmlNodeList list = root.SelectNodes(field.Name);
							if(list == null || list.Count != 1) continue;
							field.SetValue(ret, LoadNode(domain,
								list[0], field.FieldType));
						}
					}
				}


			}
			catch(Exception exception)
			{
				Console.WriteLine(exception.Message);
				ret = null;
			}

			return ret;
		}





		public static void Save(string filename, object data)
		{
			XmlDocument document = new XmlDocument();
			Type type = data.GetType();
			XmlNode root = document.CreateElement("meta");
			document.AppendChild(root);

			XmlAttribute desc = document.CreateAttribute("description");
			desc.Value = Description;
			XmlAttribute ver = document.CreateAttribute("version");
			ver.Value = Version;
			root.Attributes.Append(desc);
			root.Attributes.Append(ver);
			
			SaveNode(document, root, null, data);

			document.Save(filename);
		}

		private static void SaveNode(XmlDocument document, 
			XmlNode root, MemberInfo info, object data)
		{
			XmlNode child;
			if(data == null) return;
			Type type = data.GetType();
			if(info != null) child = document.CreateElement(info.Name);
			else child = document.CreateElement(type.FullName);
			root.AppendChild(child);

			try
			{
				if(type.IsPrimitive)
				{
					// int, float, double, ...
					MethodInfo m = typeof(object).GetMethod("ToString");
					child.InnerText = (string)m.Invoke(data, null);
				} 
				else if(type.IsEnum)
				{
					// enumeration // TODO
				} 
				else if(type.IsValueType)
				{
					// for Vector2, Vector3, Vector4, Matrix
					// for self-made stuctures

					object val;

					// Query for public variables
					FieldInfo[] fields = type.GetFields();
					foreach(FieldInfo field in fields)
					{
						if(field.IsStatic) continue;
						val = field.GetValue(data);
						SaveNode(document, child, field, val);
					}
				}


				if(type.Equals(typeof(string)))
				{
					child.InnerText = (string)data;
				}
				else if(type.IsArray)
				{
					// arrays
					Array array = data as Array;
					foreach(object val in array)
					{
						SaveNode(document, child, null, val);
					}
				} 
				else if(typeof(IList).IsInstanceOfType(data))
				{
					// lists
					IList list = data as IList;
					foreach(object val in list)
					{
						SaveNode(document, child, null, val);
					}
				}
				else if(type.IsClass)
				{
					if(info != null)
					{
						XmlNode n = document.CreateElement(
							data.GetType().FullName);
						child.AppendChild(n);
						child = n;
					}
					
					object val;

					// Query for properties
					PropertyInfo[] properties = type.GetProperties();
					foreach(PropertyInfo property in properties)
					{
						val = property.GetValue(data, null);
						SaveNode(document, child, property, val);
					}

					// Query for public variables
					FieldInfo[] fields = type.GetFields();
					foreach(FieldInfo field in fields)
					{
						if(field.IsStatic) continue;
						val = field.GetValue(data);
						SaveNode(document, child, field, val);
					}
				}
			}
			catch(Exception exception)
			{
				Console.WriteLine(exception.Message);
			}

		}

	} // End of Class



	class AssemblyDomain
	{
		private AppDomain current;
		private Assembly[] assemblies;
		private string[] names;

		public AssemblyDomain()
		{
			current = AppDomain.CurrentDomain;
			assemblies = current.GetAssemblies();
			names = new string[assemblies.Length];
			for(int i = 0; i < assemblies.Length; i++)
			{
				names[i] = assemblies[i].GetName().Name;
			}
		}

		public Type GetType(string full_name)
		{
			Type ret = Type.GetType(full_name);
			if(ret != null) return ret;

			int idx = full_name.LastIndexOf('.');
//			string class_name = full_name.Substring(idx + 1);
			string assembly_name = "";
			if(idx != -1) assembly_name = full_name.Substring(0, idx);

			idx = -1;
			for(int i = 0; i < names.Length; i++)
			{
				if(names[i].Equals(assembly_name))
				{
					ret = assemblies[i].GetType(full_name, true);
					break;
				}
			}

			return ret;
		}
	} // End of class Assembly Domain




} // End of Name Space
