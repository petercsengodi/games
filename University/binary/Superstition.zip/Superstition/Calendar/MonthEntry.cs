using System;

namespace Calendar
{
	/// <summary>
	/// Summary description for MonthEntry.
	/// </summary>
	public class MonthEntry
	{
		private int month;
		protected DayEntry[] days; 

		public int Month
		{
			get { return month; }
		}

		public MonthEntry(int month)
		{
			this.month = month;
			days = new DayEntry[31];
		}

	} // End of class Month Entry
}
