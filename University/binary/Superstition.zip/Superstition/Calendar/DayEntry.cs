using System;

namespace Calendar
{
	/// <summary>
	/// Summary description for DayEntry.
	/// </summary>
	public class DayEntry
	{
		private int day;

		public int Day
		{
			get { return day; }
		}

		public DayEntry(int day)
		{
			this.day = day;
		}

	} // End of class Day Entry
}
