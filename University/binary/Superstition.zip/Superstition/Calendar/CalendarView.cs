using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Calendar
{
	/// <summary>
	/// Summary description for CalendarView.
	/// </summary>
	public class CalendarView : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CalendarView()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			grid = new DayView[7,6];			
			SetActualMonth(DateTime.Today);
		}

		private DayView[,] grid;
		private bool grid_clear;
		private DateTime actual_month;
		private DayView selected;
		private int min_day_idx;

		public DateTime ActualMonth
		{
			get{ return actual_month; }
		}

		public void SetActualMonth(DateTime new_month)
		{
			if((new_month.Year != actual_month.Year) ||
				(new_month.Month != actual_month.Month))
			{
				actual_month = new_month;
				FillGrid(new_month);
			}

			int row, line;
			row = (min_day_idx + new_month.Day - 1) % 7;
			line = (min_day_idx + new_month.Day - 1) / 7;
			selected = grid[row, line];
			ChangeSelection();
		}

		public DayView Selected
		{
			get { return selected; }
			set
			{
				selected = value;
				ChangeSelection();
				Resources.MonthCalendar.SetDate(selected.Date);
			}
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// CalendarView
			// 
			this.Name = "CalendarView";
			this.Size = new System.Drawing.Size(728, 576);

		}
		#endregion

		/// <summary>
		/// Clears the calendar grid.
		/// </summary>
		public void ClearGrid()
		{
			if(grid_clear) return;
			for(int i = 0; i < 7; i++)
			{
				for(int j = 0; j < 6; j++)
				{
					if(grid[i,j] != null)
					{

						Controls.Remove(grid[i,j]);
						grid[i,j].Dispose();
						grid[i,j] = null;

					}
				}
			}
			grid_clear = true;
		}

		/// <summary>
		/// Fills calendar grid with a given month.
		/// </summary>
		/// <param name="date"></param>
		public void FillGrid(DateTime date)
		{
			if(!grid_clear) ClearGrid();
			int year = date.Year;
			int month = date.Month;
			int line = 0, row = 0;

			DateTime cycle = new DateTime(year, month, 1);
			
			row = (int)cycle.DayOfWeek;
			if(row < 1) row = 7;
			row --;
			min_day_idx = row;

			while(cycle.Month == month)
			{
				grid[row, line] = new DayView();
				grid[row, line].Location = new Point(
					grid[row, line].Size.Width * row, 
					grid[row, line].Size.Height * line);
				grid[row, line].Date = cycle;
				Controls.Add(grid[row, line]);
				row ++;
				if(row > 6){ row = 0; line++;}
				cycle = cycle.AddDays(1);
			}

			grid_clear = false;
		}

		/// <summary>
		/// Changes selection graphics.
		/// </summary>
		private void ChangeSelection()
		{
			for(int i = 0; i < 7; i++)
			{
				for(int j = 0; j < 6; j++)
				{
					if(grid[i,j] != null)
					{
						grid[i,j].Select(selected);
					}
				}
			}
		}

	}

}
