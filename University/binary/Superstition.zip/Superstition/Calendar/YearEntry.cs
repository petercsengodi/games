using System;

namespace Calendar
{
	/// <summary>
	/// Summary description for YearEntry.
	/// </summary>
	public class YearEntry
	{
		private int year;
		private YearEntry next;
		private MonthEntry[] months;

		public int Year
		{
			get { return year; }
		}

		public YearEntry Next
		{
			get { return next; }
			set { next = value; }
		}

		public YearEntry(int year)
		{
			this.year = year;
			months = new MonthEntry[12];
		}


	}
}
