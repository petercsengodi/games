using System;

namespace Calendar
{
	/// <summary>
	/// A memory representation of the calendar.
	/// </summary>
	public class CalendarModel
	{
		private YearEntry first_entry;
		public CalendarModel()
		{
			first_entry = null;
		}

		/// <summary>
		/// Adds a new entry to the list of years. If year exist
		/// in the list, no new will be created, but returns with
		/// the reference of the entry.
		/// </summary>
		/// <param name="year">Year to add.</param>
		/// <returns>Reference of year entry.</returns>
		private YearEntry AddYearEntry(int year)
		{
			YearEntry ret = null;
			if(first_entry == null)
			{
				first_entry = new YearEntry(year);
				ret = first_entry;
				return ret;
			}

			YearEntry temp = first_entry;
			if(year < first_entry.Year)
			{
				first_entry = new YearEntry(year);
				first_entry.Next = temp;
				ret = first_entry;
				return ret;
			}

			while(temp != null)
			{
				if(temp.Year == year)
				{
					ret = temp;
					break;
				}

				if(temp.Next == null)
				{
					ret = new YearEntry(year);
					temp.Next = ret;
					break;
				}

				if(temp.Next.Year < year)
				{
					ret = new YearEntry(year);
					ret.Next = temp.Next;
					temp.Next = ret;
					break;
				}

				temp = temp.Next;
			}

			return ret;
		}

		/// <summary>
		/// Removes an entry from the lists of years.
		/// </summary>
		/// <param name="year">Year to remove.</param>
		private void RemoveYearEntry(int year)
		{
			if(first_entry == null) return;
			if(first_entry.Year == year)
			{
				first_entry = first_entry.Next;
			}

			YearEntry temp = first_entry;
			while(temp.Next != null)
			{
				if(temp.Next.Year == year)
				{
					temp.Next = temp.Next.Next;
				}
				temp = temp.Next;
			}

		}

		/// <summary>
		/// Clears list of years.
		/// </summary>
		public void Clear()
		{
			first_entry = null;
		}

	} // End of class Calendar Model
}
