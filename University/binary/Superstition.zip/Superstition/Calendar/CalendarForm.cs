using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using FileOperations;

namespace Calendar
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class CalendarForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MonthCalendar basic;
		private System.Windows.Forms.MainMenu main_menu;
		private System.Windows.Forms.MenuItem file_menu;
		private System.Windows.Forms.MenuItem help_menu;
		private System.Windows.Forms.MenuItem about_item;
		private System.Windows.Forms.MenuItem new_item;
		private System.Windows.Forms.MenuItem open_item;
		private System.Windows.Forms.MenuItem save_item;
		private System.Windows.Forms.MenuItem saveas_item;
		private System.Windows.Forms.MenuItem exit_item;
		private System.Windows.Forms.TabControl tab_control;
		private System.Windows.Forms.TabPage calendar_page;
		private Calendar.CalendarView calendar_map;
		private System.Windows.Forms.TabPage schedule_page;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public CalendarForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			Resources.SetCalendarView(calendar_map);
			Resources.SetForm(this);
			Resources.SetMonthCalendar(basic);
			file_control = new FileControl(
				"Calendar file (*.cal)|*.cal|XML files (*.xml)|*.xml|All files (*.*)|*.*",
				".",
				null,
				null);
		}

		private FileControl file_control;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.basic = new System.Windows.Forms.MonthCalendar();
			this.main_menu = new System.Windows.Forms.MainMenu();
			this.file_menu = new System.Windows.Forms.MenuItem();
			this.new_item = new System.Windows.Forms.MenuItem();
			this.open_item = new System.Windows.Forms.MenuItem();
			this.save_item = new System.Windows.Forms.MenuItem();
			this.saveas_item = new System.Windows.Forms.MenuItem();
			this.exit_item = new System.Windows.Forms.MenuItem();
			this.help_menu = new System.Windows.Forms.MenuItem();
			this.about_item = new System.Windows.Forms.MenuItem();
			this.tab_control = new System.Windows.Forms.TabControl();
			this.calendar_page = new System.Windows.Forms.TabPage();
			this.calendar_map = new Calendar.CalendarView();
			this.schedule_page = new System.Windows.Forms.TabPage();
			this.tab_control.SuspendLayout();
			this.calendar_page.SuspendLayout();
			this.SuspendLayout();
			// 
			// basic
			// 
			this.basic.Location = new System.Drawing.Point(24, 16);
			this.basic.Name = "basic";
			this.basic.TabIndex = 0;
			this.basic.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.basic_DateChanged);
			// 
			// main_menu
			// 
			this.main_menu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.file_menu,
																					  this.help_menu});
			// 
			// file_menu
			// 
			this.file_menu.Index = 0;
			this.file_menu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.new_item,
																					  this.open_item,
																					  this.save_item,
																					  this.saveas_item,
																					  this.exit_item});
			this.file_menu.Text = "File";
			// 
			// new_item
			// 
			this.new_item.Index = 0;
			this.new_item.Text = "New";
			this.new_item.Click += new System.EventHandler(this.new_item_Click);
			// 
			// open_item
			// 
			this.open_item.Index = 1;
			this.open_item.Text = "Open";
			this.open_item.Click += new System.EventHandler(this.open_item_Click);
			// 
			// save_item
			// 
			this.save_item.Index = 2;
			this.save_item.Text = "Save";
			this.save_item.Click += new System.EventHandler(this.save_item_Click);
			// 
			// saveas_item
			// 
			this.saveas_item.Index = 3;
			this.saveas_item.Text = "Save As ...";
			this.saveas_item.Click += new System.EventHandler(this.saveas_item_Click);
			// 
			// exit_item
			// 
			this.exit_item.Index = 4;
			this.exit_item.Text = "Exit";
			this.exit_item.Click += new System.EventHandler(this.exit_item_Click);
			// 
			// help_menu
			// 
			this.help_menu.Index = 1;
			this.help_menu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.about_item});
			this.help_menu.Text = "Help";
			// 
			// about_item
			// 
			this.about_item.Index = 0;
			this.about_item.Text = "About";
			this.about_item.Click += new System.EventHandler(this.about_item_Click);
			// 
			// tab_control
			// 
			this.tab_control.Controls.Add(this.calendar_page);
			this.tab_control.Controls.Add(this.schedule_page);
			this.tab_control.Location = new System.Drawing.Point(240, 8);
			this.tab_control.Name = "tab_control";
			this.tab_control.SelectedIndex = 0;
			this.tab_control.Size = new System.Drawing.Size(744, 608);
			this.tab_control.TabIndex = 1;
			// 
			// calendar_page
			// 
			this.calendar_page.Controls.Add(this.calendar_map);
			this.calendar_page.Location = new System.Drawing.Point(4, 22);
			this.calendar_page.Name = "calendar_page";
			this.calendar_page.Size = new System.Drawing.Size(736, 582);
			this.calendar_page.TabIndex = 0;
			this.calendar_page.Text = "Calendar";
			// 
			// calendar_map
			// 
			this.calendar_map.Location = new System.Drawing.Point(8, 8);
			this.calendar_map.Name = "calendar_map";
			this.calendar_map.Size = new System.Drawing.Size(728, 576);
			this.calendar_map.TabIndex = 0;
			// 
			// schedule_page
			// 
			this.schedule_page.Location = new System.Drawing.Point(4, 22);
			this.schedule_page.Name = "schedule_page";
			this.schedule_page.Size = new System.Drawing.Size(736, 582);
			this.schedule_page.TabIndex = 1;
			this.schedule_page.Text = "Day Schedule";
			// 
			// CalendarForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1002, 627);
			this.Controls.Add(this.tab_control);
			this.Controls.Add(this.basic);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Menu = this.main_menu;
			this.Name = "CalendarForm";
			this.Text = "Calendar Program for Thesis Plan";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.CalendarForm_Closing);
			this.tab_control.ResumeLayout(false);
			this.calendar_page.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new CalendarForm());
		}

		private void exit_item_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void CalendarForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			file_control.Save();
		}

		private void new_item_Click(object sender, System.EventArgs e)
		{
			file_control.New();
		}

		private void open_item_Click(object sender, System.EventArgs e)
		{
			file_control.Open();
		}

		private void save_item_Click(object sender, System.EventArgs e)
		{
			file_control.Save();
		}

		private void saveas_item_Click(object sender, System.EventArgs e)
		{
			file_control.SaveAs();
		}

		private void about_item_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("Calendar help program\nCreated by P�ter Cseng�di\n2006.", "About Calendar");
		}

		private void basic_DateChanged(object sender, System.Windows.Forms.DateRangeEventArgs e)
		{
			calendar_map.SetActualMonth(e.Start);
		}

	}

	public class Resources
	{
		private static CalendarView calendar_view;
		private static CalendarForm form;
		private static MonthCalendar month_calendar;

		public static CalendarView CalendarView
		{
			get { return calendar_view; }
		}

		public static CalendarForm Form
		{
			get { return form; }
		}

		public static MonthCalendar MonthCalendar
		{
			get { return month_calendar; }
		}

		public static void SetCalendarView(CalendarView calendarView)
		{
			calendar_view = calendarView;
		}

		public static void SetForm(CalendarForm calendarForm)
		{
			form = calendarForm;
		}

		public static void SetMonthCalendar(MonthCalendar monthCalendar)
		{
			month_calendar = monthCalendar;
		}
	}
}
