using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace Calendar
{
	/// <summary>
	/// Summary description for DayView.
	/// </summary>
	public class DayView : System.Windows.Forms.UserControl
	{
		private System.Windows.Forms.TextBox year_box;
		private System.Windows.Forms.TextBox month_box;
		private System.Windows.Forms.TextBox day_box;
		private System.Windows.Forms.ListBox item_list;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DayView()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			
			_year = "2006";
			_month = "01";
			_day = "01";
		}

		private string _year, _month, _day;
		private DateTime date;

		public DateTime Date
		{
			get{ return date; }
			set
			{
				date = value;
				_year = value.Year.ToString();
				_month = value.Month.ToString();
				_day = value.Day.ToString();
				
				while(_month.Length < 2)
				{
					_month = "0" + _month;
				}

				while(_day.Length < 2)
				{
					_day = "0" + _day;
				}

				year_box_TextChanged(null, null);
				month_box_TextChanged(null, null);
				day_box_TextChanged(null, null);
			}
		}


		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.year_box = new System.Windows.Forms.TextBox();
			this.month_box = new System.Windows.Forms.TextBox();
			this.day_box = new System.Windows.Forms.TextBox();
			this.item_list = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// year_box
			// 
			this.year_box.Location = new System.Drawing.Point(8, 8);
			this.year_box.Name = "year_box";
			this.year_box.ReadOnly = true;
			this.year_box.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.year_box.Size = new System.Drawing.Size(40, 20);
			this.year_box.TabIndex = 3;
			this.year_box.Text = "2006";
			this.year_box.TextChanged += new System.EventHandler(this.year_box_TextChanged);
			this.year_box.Enter += new System.EventHandler(this.DayView_Click);
			// 
			// month_box
			// 
			this.month_box.Location = new System.Drawing.Point(48, 8);
			this.month_box.Name = "month_box";
			this.month_box.ReadOnly = true;
			this.month_box.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.month_box.Size = new System.Drawing.Size(24, 20);
			this.month_box.TabIndex = 4;
			this.month_box.Text = "01";
			this.month_box.TextChanged += new System.EventHandler(this.month_box_TextChanged);
			this.month_box.Enter += new System.EventHandler(this.DayView_Click);
			// 
			// day_box
			// 
			this.day_box.Location = new System.Drawing.Point(72, 8);
			this.day_box.Name = "day_box";
			this.day_box.ReadOnly = true;
			this.day_box.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.day_box.Size = new System.Drawing.Size(24, 20);
			this.day_box.TabIndex = 5;
			this.day_box.Text = "01";
			this.day_box.TextChanged += new System.EventHandler(this.day_box_TextChanged);
			this.day_box.Enter += new System.EventHandler(this.DayView_Click);
			// 
			// item_list
			// 
			this.item_list.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.item_list.Location = new System.Drawing.Point(8, 32);
			this.item_list.Name = "item_list";
			this.item_list.Size = new System.Drawing.Size(88, 56);
			this.item_list.TabIndex = 6;
			this.item_list.Enter += new System.EventHandler(this.DayView_Click);
			// 
			// DayView
			// 
			this.BackColor = System.Drawing.SystemColors.Control;
			this.Controls.Add(this.item_list);
			this.Controls.Add(this.day_box);
			this.Controls.Add(this.month_box);
			this.Controls.Add(this.year_box);
			this.ForeColor = System.Drawing.SystemColors.ControlText;
			this.Name = "DayView";
			this.Size = new System.Drawing.Size(104, 96);
			this.Click += new System.EventHandler(this.DayView_Click);
			this.DoubleClick += new System.EventHandler(this.DayView_Click);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Changes selection graphics.
		/// </summary>
		/// <param name="day_view"></param>
		public void Select(DayView day_view)
		{
			if(day_view == this)
			{
				this.BackColor = Color.Red;
			} 
			else 
			{
				this.BackColor = Control.DefaultBackColor;
			}

			Invalidate();
		}

		private void year_box_TextChanged(object sender, System.EventArgs e)
		{
			year_box.Text = _year;
		}

		private void month_box_TextChanged(object sender, System.EventArgs e)
		{
			month_box.Text = _month;
		}

		private void day_box_TextChanged(object sender, System.EventArgs e)
		{
			day_box.Text = _day;

		}

		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint (e);
		}

		private void DayView_Click(object sender, System.EventArgs e)
		{
			Resources.CalendarView.Selected = this;
		}

	}
}
