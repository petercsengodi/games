using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace T3DCreator
{
	/// <summary>
	/// Summary description for MeshUtils.
	/// </summary>
	public class MeshUtils : IDisposable
	{
		private SaveFileDialog dialog;
		
		protected Device device;
		protected Mesh mesh;
		protected ExtendedMaterial[] materials;
		protected int[] adjacency;
		protected int num_faces, num_vertices;

		public MeshUtils(Device device)
		{
			this.device = device;
			dialog = new SaveFileDialog();
			dialog.Filter = "Mesh Files (*.x)|*.x|All files (*.*)|*.*";
			dialog.InitialDirectory = @"..\..\..\Superstition\bin\meshes";
			dialog.RestoreDirectory = true;
		}

		public void Export(CModel model)
		{
			DialogResult res = dialog.ShowDialog();
			if(res == DialogResult.Cancel) return;
			if(res == DialogResult.No) return;
			
			num_faces = 0;
			num_vertices = 0;

			foreach(CFigure f in model.figures)
			{
				num_vertices += f.vertices.Count;
				num_faces += f.triangles.Count;
			}

			mesh = new Mesh(num_faces, num_vertices, 0,
				CustomVertex.PositionNormalTextured.Format, device);

			materials = null;

			BuildMesh(mesh, model);

			mesh.Save(dialog.FileName, adjacency, materials, 
				XFileFormat.Text);
		}

		public void BuildMesh(Mesh mesh, CModel model)
		{
			int si = 0; // start index
//			int sf = 0; // start face

			using(VertexBuffer vbuf = mesh.VertexBuffer)
			{
				GraphicsStream vb = vbuf.Lock(0, 0, LockFlags.None);

				foreach(CFigure f in model.figures)
				{

					foreach(CVertex v in f.vertices)
					{
						vb.Write(new CustomVertex.PositionNormalTextured(
							v.position,
							new Vector3(0f, 0f, 0f),
							v.texture_coordinates.X,
							v.texture_coordinates.Y));
					}
				}

				vbuf.Unlock();
			}

			using(IndexBuffer ibuf = mesh.IndexBuffer)
			{
				GraphicsStream ib = ibuf.Lock(0, 0, LockFlags.None);

				foreach(CFigure f in model.figures)
				{
					foreach(CTriangle t in f.triangles)
					{
						ib.Write((short)( si + 
							f.vertices.IndexOf(t.vertices[0])));
						ib.Write((short)( si + 
							f.vertices.IndexOf(t.vertices[1])));
						ib.Write((short)( si + 
							f.vertices.IndexOf(t.vertices[2])));
					}

					si += f.vertices.Count;
				}

				ibuf.Unlock();
			}

			adjacency = new int[num_faces * 3];

			#region Generate Adjacency
			
			// mesh.GenerateAdjacency(float.Epsilon, adjacency);

			int tidx = 0;
			int idx, start = 0;
			foreach(CFigure f in model.figures)
			{
				// for every triangle in figure set adjacency information
				foreach(CTriangle t in f.triangles)
				{
					idx = -1;

					// for every vertex
					for(int i = 0; i < 3; i++)
					{
						// next vertex index in array
						int j = (i+1) % 3;
						foreach(CTriangle t2 in t.vertices[i].triangles)
						{
							// if same triangle, keep on searching
							if(t.Equals(t2)) continue; 
							// if both triangle has two same vertexes,
							//  set information and stop searching
							if(t2.vertices[0].Equals(t.vertices[j]) ||
								t2.vertices[1].Equals(t.vertices[j]) ||
								t2.vertices[2].Equals(t.vertices[j]))
							{
								// index of t2 in indexbuffer
								adjacency[tidx*3 + i] =
									start + f.triangles.IndexOf(t2);
								break;
							}
						}
					}
					
					tidx++;
				}
				start += f.triangles.Count;
			}

			#endregion
						
			mesh.ComputeNormals(adjacency);
			materials = new ExtendedMaterial[model.figures.Count];

//			AttributeRange[] ranges = new AttributeRange[model.figures.Count];
//			si = sf = 0;

			for(int i = 0; i < model.figures.Count; i++)
			{
				CFigure f = model.figures[i] as CFigure;
				materials[i] = new ExtendedMaterial();
				if(f.texID != null)
				{
					materials[i].TextureFilename = f.texID.name;
				} 
				else 
				{
					materials[i].TextureFilename = null;
				}

				Material mat = new Material();
				mat.Ambient = Color.FromArgb(f.ambient_color);
				mat.Diffuse = Color.FromArgb(f.diffuse_color);
				mat.Emissive = Color.FromArgb(f.emissive_color);
				materials[i].Material3D = mat;

//				ranges[i] = new AttributeRange();
//				ranges[i].AttributeId = i;
//				ranges[i].FaceCount = f.triangles.Count;
//				ranges[i].FaceStart = sf;
//				sf += f.triangles.Count;
//				ranges[i].VertexCount = f.vertices.Count;
//				ranges[i].VertexStart = si;
//				si += f.vertices.Count;
			}

//			mesh.SetAttributeTable(ranges);

			int index = 0;
			int[] array = mesh.LockAttributeBufferArray(LockFlags.Discard);
//			GraphicsStream gs = mesh.LockAttributeBuffer(0);
			for(int i = 0; i < model.figures.Count; i++)
			{
				CFigure f = (model.figures[i] as CFigure);
				for(int j = 0; j < f.triangles.Count; j++)
				{
					array[index++] = i;
//					gs.Write((byte)0x1);
				}
			}

			mesh.UnlockAttributeBuffer(array);
			mesh.Optimize(MeshFlags.OptimizeAttributeSort, adjacency);
//			mesh.OptimizeInPlace(MeshFlags.OptimizeAttributeSort, adjacency);

		} // End of function

		#region IDisposable Members

		public void Dispose()
		{
			dialog.Dispose();
		}

		#endregion

	}
}
