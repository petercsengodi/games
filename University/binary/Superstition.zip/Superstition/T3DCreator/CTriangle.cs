using System;

using Microsoft.DirectX;

namespace T3DCreator
{
	/// <summary>
	/// Summary description for CTriangle.
	/// </summary>
	public class CTriangle : IPart
	{
		public CVertex[] vertices;
		public CEdge[] edges;

		private CTriangle()
		{
			vertices = new CVertex[3];
			edges = new CEdge[3];
		}

		public CTriangle(CVertex a, CVertex b, CVertex c)
		{
			vertices = new CVertex[3];

			vertices[0] = a;
			vertices[1] = b;
			vertices[2] = c;
			JoinNeighbours();
		}

		public CTriangle(object a, object b, object c)
		{
			vertices = new CVertex[3];

			vertices[0] = (CVertex)a;
			vertices[1] = (CVertex)b;
			vertices[2] = (CVertex)c;
			JoinNeighbours();
		}

		private void JoinNeighbours()
		{
			edges = new CEdge[3];

			// Create neighbour information
			for(int i = 0; i < 3; i++)
			{
				for(int j = i+1; j < 3; j++)
				{
					if(vertices[i].neighbours.IndexOf(vertices[j]) == -1)
					{
						vertices[i].neighbours.Add(vertices[j]);
					}
					if(vertices[j].neighbours.IndexOf(vertices[i]) == -1)
					{
						vertices[j].neighbours.Add(vertices[i]);
					}

				}
				
				// Create vertex -> triangle association; other
				//		direction is done
				vertices[i].triangles.Add(this);
			}

			// Create edge <-> triangle association
			// Create vertex <-> edge association
			for(int i = 0; i < 3; i++)
			{
				int j = (i + 1) % 3;
				edges[i] = new CEdge(vertices[i], vertices[j]);
				vertices[i].edges.Add(edges[i]);
				vertices[j].edges.Add(edges[i]);
				edges[i].triangle = this;
			}
		} // End of function Join Neighbours

		public DiscardResult Split(CFigure figure, CModel model)
		{
			DiscardResult ret = new DiscardResult();

			CVertex
				a = vertices[0],
				b = vertices[1],
				c = vertices[2];
			
			// Delete old triangle, edges, but no vertices
			// Neighbour informations don't change

			figure.triangles.Remove(this); // remove triangle from figure
			a.triangles.Remove(this); // remove triangle from vertices
			b.triangles.Remove(this);
			c.triangles.Remove(this);

			// This triangle is the only one removed
			ret.old_triangles = new CTriangle[]{this};
			// No vertices were removed
			ret.old_vertices = new CVertex[0];
			
			foreach(CEdge e in edges) // remove triangle edges from vertices
			{
				e.from.edges.Remove(e);
				e.to.edges.Remove(e);
			}

			// Add new vertex to the figure

			Vector3 new_pos = new Vector3();
			new_pos.X = (a.position.X + b.position.X + c.position.X) / 3f;
			new_pos.Y = (a.position.Y + b.position.Y + c.position.Y) / 3f;
			new_pos.Z = (a.position.Z + b.position.Z + c.position.Z) / 3f;

			
			if(model.SnapToGrid)
			{
				new_pos.X = (float)(Math.Round(new_pos.X / model.grid_step) * model.grid_step);
				new_pos.Y = (float)(Math.Round(new_pos.Y / model.grid_step) * model.grid_step);
				new_pos.Z = (float)(Math.Round(new_pos.Z / model.grid_step) * model.grid_step);
			}
		
			Vector2 new_tex = new Vector2();
			new_tex.X = (a.texture_coordinates.X + b.texture_coordinates.X + 
				c.texture_coordinates.X) / 3f;
			new_tex.Y = (a.texture_coordinates.Y + b.texture_coordinates.Y + 
				c.texture_coordinates.Y) / 3f;
			CVertex v = new CVertex(new_pos);
			v.texture_coordinates = new_tex;
			figure.vertices.Add(v);
			
			// Only one vertex is added
			ret.new_vertices = new CVertex[]{v};

			// Create three new triangles

			CTriangle t;
			ret.new_triangles = new CTriangle[3];
			t = new CTriangle(v, a, b);
			figure.triangles.Add(t);
			ret.new_triangles[0] = t;
			t = new CTriangle(v, b, c);
			figure.triangles.Add(t);
			ret.new_triangles[1] = t;
			t = new CTriangle(v, c, a);
			figure.triangles.Add(t);
			ret.new_triangles[2] = t;

			return ret;
		}

		public override string ToString()
		{
			return "Triangle";
		}

		#region IPart Members

		public void move(Vector3 direction)
		{
			foreach(CVertex v in this.vertices)
			{
				v.move(direction);
			}
		}

		public void moveTexture(Vector2 direction)
		{
			foreach(CVertex v in this.vertices)
			{
				v.moveTexture(direction);
			}
		}

		#endregion

		public static object GetNullInstance()
		{
			return new CTriangle();
		}

	} // End of class CTriangle

	public class DiscardResult
	{
		public CTriangle[] old_triangles;
		public CVertex[] old_vertices;

		public CTriangle[] new_triangles;
		public CVertex[] new_vertices;

		public DiscardResult()
		{
			old_triangles = null;
			old_vertices = null;
			new_triangles = null;
			new_vertices = null;
		}
	}
}
