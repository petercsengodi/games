using System;
using System.Drawing;
using System.Collections;

using Microsoft.DirectX;

namespace T3DCreator
{
	/// <summary>
	/// Summary description for CFigure.
	/// </summary>
	public class CFigure : IPart
	{
		public ArrayList vertices;
		public ArrayList triangles;
		public TexID texID;
		public int ambient_color;
		public int diffuse_color;
		public int emissive_color;

		private CFigure()
		{
			vertices = new ArrayList();
			triangles = new ArrayList();
			texID = null;
			
			ambient_color = Color.White.ToArgb();
			diffuse_color = Color.White.ToArgb();
			emissive_color = Color.Black.ToArgb();
		}

		public CFigure(InitialFigure figure)
		{
			vertices = new ArrayList();
			triangles = new ArrayList();
			texID = null;

			ambient_color = Color.White.ToArgb();
			diffuse_color = Color.White.ToArgb();
			emissive_color = Color.Black.ToArgb();

			switch(figure)
			{
				case InitialFigure.Cube:
					AddNewCube();
					break;

				default:
					AddNewTetra();
					break;
			}
		}

		public void AddNewTetra()
		{
			vertices.Add(new CVertex(new Vector3(0f, 0f, 0f)));
			vertices.Add(new CVertex(new Vector3(1f, 0f, 0f)));
			vertices.Add(new CVertex(new Vector3(1f, 0f, 1f)));
			vertices.Add(new CVertex(new Vector3(0f, 1f, 0f)));

			triangles.Add(new CTriangle(
				vertices[0], vertices[1], vertices[2]));
			triangles.Add(new CTriangle(
				vertices[1], vertices[0], vertices[3]));
			triangles.Add(new CTriangle(
				vertices[2], vertices[1], vertices[3]));
			triangles.Add(new CTriangle(
				vertices[0], vertices[2], vertices[3]));

			(vertices[0] as CVertex).texture_coordinates = new Vector2(0f, 0f);
			(vertices[1] as CVertex).texture_coordinates = new Vector2(0f, 1f);
			(vertices[2] as CVertex).texture_coordinates = new Vector2(1f, 0f);
			(vertices[3] as CVertex).texture_coordinates = new Vector2(1f, 1f);
		}

		public void AddNewCube()
		{
			vertices.Add(new CVertex(new Vector3(0f, 0f, 0f)));
			vertices.Add(new CVertex(new Vector3(1f, 0f, 0f)));
			vertices.Add(new CVertex(new Vector3(0f, 1f, 0f)));
			vertices.Add(new CVertex(new Vector3(1f, 1f, 0f)));
			vertices.Add(new CVertex(new Vector3(0f, 0f, 1f)));
			vertices.Add(new CVertex(new Vector3(1f, 0f, 1f)));
			vertices.Add(new CVertex(new Vector3(0f, 1f, 1f)));
			vertices.Add(new CVertex(new Vector3(1f, 1f, 1f)));

			triangles.Add(new CTriangle(
				vertices[2], vertices[1], vertices[0]));
			triangles.Add(new CTriangle(
				vertices[2], vertices[3], vertices[1]));

			triangles.Add(new CTriangle(
				vertices[4], vertices[5], vertices[6]));
			triangles.Add(new CTriangle(
				vertices[7], vertices[6], vertices[5]));

			triangles.Add(new CTriangle(
				vertices[1], vertices[3], vertices[5]));
			triangles.Add(new CTriangle(
				vertices[3], vertices[7], vertices[5]));

			triangles.Add(new CTriangle(
				vertices[2], vertices[0], vertices[6]));
			triangles.Add(new CTriangle(
				vertices[0], vertices[4], vertices[6]));

			triangles.Add(new CTriangle(
				vertices[4], vertices[0], vertices[1]));
			triangles.Add(new CTriangle(
				vertices[4], vertices[1], vertices[5]));

			triangles.Add(new CTriangle(
				vertices[2], vertices[6], vertices[3]));
			triangles.Add(new CTriangle(
				vertices[6], vertices[7], vertices[3]));

			(vertices[0] as CVertex).texture_coordinates = new Vector2(0.333f, 0.666f);
			(vertices[1] as CVertex).texture_coordinates = new Vector2(0.666f, 0.666f);
			(vertices[2] as CVertex).texture_coordinates = new Vector2(0.333f, 0.333f);
			(vertices[3] as CVertex).texture_coordinates = new Vector2(0.666f, 0.333f);
			(vertices[4] as CVertex).texture_coordinates = new Vector2(0f, 1f);
			(vertices[5] as CVertex).texture_coordinates = new Vector2(1f, 1f);
			(vertices[6] as CVertex).texture_coordinates = new Vector2(0f, 0f);
			(vertices[7] as CVertex).texture_coordinates = new Vector2(1f, 0f);
		}

		public void AddNewSphere()
		{
			// TODO: Sphere
		}

		public override string ToString()
		{
			return "Figure";
		}

		#region IPart Members

		public void move(Vector3 direction)
		{
			foreach(CVertex v in this.vertices)
			{
				v.move(direction);
			}
		}

		public void moveTexture(Vector2 direction)
		{
			foreach(CVertex v in this.vertices)
			{
				v.moveTexture(direction);
			}
		}

		#endregion

		public void zoom(float factor)
		{
			Vector3 average = new Vector3(0f, 0f, 0f);
			float num = 1f / vertices.Count;
			foreach(CVertex v in vertices)
			{
				average += v.position * num;
			}

			foreach(CVertex v in vertices)
			{
				v.position = ((v.position - average) * factor)
					+ average;
			}
		}

		public static object GetNullInstance()
		{
			return new CFigure();
		}

		public void SphereTexture()
		{
			Vector3 min, max, average;
			float radius = 0f;

			min = (vertices[0] as CVertex).position;
			max = (vertices[0] as CVertex).position;

			for(int i = 1; i < vertices.Count; i++)
			{
				CVertex v = vertices[i] as CVertex;
				min = Vector3.Minimize(min, v.position);
				max = Vector3.Maximize(max, v.position);
			}

			average = (min + max) * 0.5f;
			radius = Math.Max(average.X - min.X, Math.Max(
				average.Y - min.Y, average.Z - min.Z));

			foreach(CVertex v in vertices)
			{
				Vector3 tmp = v.position - average;
				tmp.Normalize();
				double ty = Math.Acos(tmp.Y) / Math.PI;
				tmp.Y = 0f;
				tmp.Normalize();
				double tx;

				if(tmp.Z >= 0f)
				{
					tx = Math.Acos(tmp.X) / Math.PI;
				} 
				else 
				{
					tx = 1.0 - Math.Acos(tmp.X) / Math.PI;
				}

                v.texture_coordinates = new Vector2((float)tx, (float)ty);
			}
		}

		public void RandomTexture()
		{
			Random random = new Random();
			foreach(CVertex v in vertices)
			{
				v.texture_coordinates.X = (float)random.NextDouble();
				v.texture_coordinates.Y = (float)random.NextDouble();
			}
		}

		public void RollBackDiscard(DiscardResult res)
		{
			// Removing new triangles
			foreach(CTriangle t in res.new_triangles)
			{
				this.triangles.Remove(t);
			}

			// Removing new vertices
			foreach(CVertex v in res.new_vertices)
			{
				this.vertices.Remove(v);
			}

			// Old triangles do not use new vertices 
			// Old vertices are used by new triangles (and vertices)
			// Deleting unnecessary information
			foreach(CVertex vertex in this.vertices)
			{
				foreach(CVertex v in res.new_vertices)
				{
					if(vertex.neighbours.IndexOf(v) != -1)
					{
						vertex.neighbours.Remove(v);
					}
				}

				foreach(CTriangle t in res.new_triangles)
				{
					if(vertex.triangles.IndexOf(t) != -1)
					{
						vertex.triangles.Remove(t);
					}

					foreach(CEdge e in t.edges)
					{
						if(vertex.edges.IndexOf(e) != -1)
						{
							vertex.edges.Remove(e);
						}
					}
				}

			} // End of deleting unnecessary information

			// Setting back old vertices
			foreach(CVertex v in res.old_vertices)
			{
				v.edges.Clear();
				v.neighbours.Clear();
				v.triangles.Clear();
				this.vertices.Add(v);
			}

			// Setting back old triangles
			//   and other informations using triangle ctor
			foreach(CTriangle t in res.old_triangles)
			{
				CTriangle newt = new CTriangle(t.vertices[0],
					t.vertices[1], t.vertices[2]);
				this.triangles.Add(t);
			}

		}

		public void Tessellate(float max_edge, CModel model)
		{
			bool cont = true;
			CEdge split_edge = null;
			bool snap = model.SnapToGrid;
			model.SetSnapToGrid(false);

			while(cont)
			{
				cont = false;
				foreach(CTriangle t in triangles)
				{
					foreach(CEdge e in t.edges)
					{
						if(e.Length() > max_edge)
						{
							split_edge = e;
							cont = true;
							break;
						}
					}
					if(cont) break;
				}

				if(cont) 
				{
					split_edge.Split(this, model);
				}

				cont = false;
			}

			model.SetSnapToGrid(snap);
		} // End of function Tessellate

	} // End of class Figure

	public enum InitialFigure
	{
		Tetra, Cube
	}
}
