using System;
using System.Drawing;

using Microsoft.DirectX;

namespace T3DCreator
{
	/// <summary>
	/// Summary description for Memento.
	/// </summary>
	public class Memento
	{
		private MItem last;
		private MItem first;

		public Memento()
		{
			last = null;
		}

		public void Push(Operation operation)
		{
			MItem new_item = new MItem();
			new_item.operation = operation;
			new_item.previous = last;
			last = new_item;
			first = null;
			operation.Do();
		}

		public Operation Undo()
		{
			Operation ret = last.operation;
	
			if(last != null)
			{
				MItem tmp = last;
				last = tmp.previous;
				tmp.previous = first;
				first = tmp;
				ret.UnDo();
			}

			return ret;
		}

		public Operation Redo()
		{
			Operation ret = null;
	
			if(first != null)
			{
				MItem tmp = first;
				first = tmp.previous;
				tmp.previous = last;
				last = tmp;
				ret = last.operation;
				ret.Do();
			}

			return ret;
		}

		public void Clear()
		{
			last = null;
			first = null;
		}
	
	} // End of class Memento

	class MItem
	{
		public MItem previous;
		public Operation operation;
	} // End of class MItem

	public class Operation
	{
		private CModel model;
		private object[] param;
		private object[] previous;
		private Operations operation;
		private bool done;

		public Operation(CModel model, Operations operation, object[] param)
		{
			this.model = model;
			this.operation = operation;
			this.param = param;
			this.done = false;
			this.previous = null;
		}

		public Operation(CModel model, Operations operation, object param)
		{
			this.model = model;
			this.operation = operation;
			this.param = new object[] {param};
			this.done = false;
			this.previous = null;
		}

		public void Do()
		{
			if(done) return;
			switch(operation)
			{
				case Operations.AddFigure:
					model.figures.Add(param[0]);
					model.Selected = param[0];
					break;

				case Operations.ChangeFigureProperty:
					previous = new object[3];
					previous[0] = (param[0] as CFigure).ambient_color;
					previous[1] = (param[0] as CFigure).diffuse_color;
					previous[2] = (param[0] as CFigure).emissive_color;
					(param[0] as CFigure).ambient_color = (int)param[1];
					(param[0] as CFigure).ambient_color = (int)param[2];
					(param[0] as CFigure).ambient_color = (int)param[3];
					break;

				case Operations.ChangeTexture:
					previous = new object[1];
					if((param[0] as CFigure).texID != null)
					{
						previous[0] = (param[0] as CFigure).texID.name;
					} else previous[0] = null;
					(param[0] as CFigure).texID = TextureLibrary.Instance().
						LoadImage(param[1] as string);
					break;

				case Operations.MovePart:
					(param[0] as IPart).move((Vector3)param[1]);
					break;

				case Operations.MoveTexture:
					(param[0] as IPart).moveTexture((Vector2)param[1]);
					break;

				case Operations.Zoom:
					(param[0] as CFigure).zoom((float)param[1]);
					break;

				case Operations.SplitEdge:
					previous = new object[2];
					previous[0] = param[0];
					previous[1] = (param[1] as CEdge).Split(
						param[0] as CFigure, model);
					break;

				case Operations.SplitTriangle:
					previous = new object[2];
					previous[0] = param[0];
					previous[1] = (param[1] as CTriangle).Split(
						param[0] as CFigure, model);
					break;

				case Operations.DeleteFigure:
					previous = new object[1];
					previous[0] = param[0];
					model.figures.Remove(param[0] as CFigure);
					break;

				default: break;
			}
			done = true;
		}

		public void UnDo()
		{
			if(!done) return;
			switch(operation)
			{
				case Operations.AddFigure:
					model.figures.Remove(param[0]);
					break;

				case Operations.ChangeFigureProperty:
					(param[0] as CFigure).ambient_color = (int)previous[0];
					(param[0] as CFigure).ambient_color = (int)previous[1];
					(param[0] as CFigure).ambient_color = (int)previous[2];
					previous = null;
					break;

				case Operations.ChangeTexture:
					if(previous[0] == null)
					{
						(param[0] as CFigure).texID = null;
					} 
					else 
					{
						(param[0] as CFigure).texID = TextureLibrary.Instance().
							LoadImage(previous[0] as string);
					}
					previous = null;
					break;

				case Operations.MovePart:
					(param[0] as IPart).move((Vector3)param[1] * -1f);
					break;

				case Operations.MoveTexture:
					(param[0] as IPart).moveTexture((Vector2)param[1] * -1f);
					break;

				case Operations.Zoom:
					(param[0] as CFigure).zoom(1f / (float)param[1]);
					break;

				case Operations.SplitEdge:
					(previous[0] as CFigure).RollBackDiscard(
						previous[1] as DiscardResult);
					break;

				case Operations.SplitTriangle:
					(previous[0] as CFigure).RollBackDiscard(
						previous[1] as DiscardResult);
					break;

				case Operations.DeleteFigure:
					(previous[1] as CModel).figures.Add(
						previous[0] as CFigure);
					break;

				default: break;
			}
			done = false;
			previous = null;
			model.Selected = null;
		}

		//
		// Setting up Operation Static Instatiater
		//

		public static Operation OpAddFigure(CModel model, InitialFigure figure)
		{
			CFigure f = new CFigure(figure);
			return new Operation(model, Operations.AddFigure, f);
		}

		public static Operation OpMovePart(CModel model, IPart part, Vector3 difference)
		{
			return new Operation(model, Operations.MovePart, 
				new object[]{part, difference});
		}

		public static Operation OpMoveTexture(CModel model, IPart part, Vector2 difference)
		{
			return new Operation(model, Operations.MoveTexture, 
				new object[]{part, difference});
		}

		public static Operation OpZoom(CModel model, CFigure figure, float zoom)
		{
			return new Operation(model, Operations.Zoom, 
				new object[]{figure, zoom});
		}

		public static Operation OpChangeFigureProperty(CModel model, CFigure figure, 
			int ambient_color, int diffuse_color, int emissive_color)
		{
			return new Operation(model, Operations.ChangeFigureProperty,
				new object[]{figure, ambient_color, diffuse_color, emissive_color});
		}

		public static Operation OpChangeTexture(CModel model, CFigure figure, string texture)
		{
			return new Operation(model, Operations.ChangeTexture,
				new object[]{figure, texture});
		}

		public static Operation OpSplitEdge(CModel model, CFigure figure, CEdge edge)
		{
			return new Operation(model, Operations.SplitEdge,
				new object[]{figure, edge});
		}

		public static Operation OpSplitTriangle(CModel model, CFigure figure, CTriangle triangle)
		{
			return new Operation(model, Operations.SplitTriangle,
				new object[]{figure, triangle});
		}

		public static Operation OpDeleteFigure(CModel model, CFigure figure)
		{
			return new Operation(model, Operations.DeleteFigure,
				new object[]{figure});
		}

	} // End of clas Operation

	public enum Operations
	{
		AddFigure, // CFigure
		MovePart, // IPart, Vector3
		MoveTexture, // IPart, Vector2
		Zoom, // CFigure, float (zoom_factor)
		ChangeFigureProperty, // CFigure, int, int, int (colors)
		ChangeTexture, // CFigure, string (texture)
		SplitEdge, // CFigure, CEdge
		SplitTriangle, // CFigure, CTriangle
		DeleteFigure // CFigure
	}
}
