using System;
using System.Collections;

using Microsoft.DirectX;

namespace T3DCreator
{
	using T3DCreatorWindows;

	/// <summary>
	/// Summary description for CModel.
	/// </summary>
	public class CModel
	{
		public ArrayList figures;
		protected ArrayList views;
		protected object selected;
		protected bool snap_to_grid;
		private Memento memento;

		public double grid_from = -10, grid_to = 10, 
			grid_step = 1.0, grid_error = 0.001;

		public bool SnapToGrid
		{
			get{ return snap_to_grid; }
		}

		public void SetSnapToGrid(bool snap_to_grid)
		{
			this.snap_to_grid = snap_to_grid;
		}

		public object Selected 
		{
			get { return selected; }
			set	{ 
				selected = value;
				UpdateViews(Updates.Selection);
			}
		}

		public Memento Executor
		{
			get{ return memento; }
		}

		public void ClearSelection()
		{
			selected = "";
		}

		public CModel()
		{
			figures = new ArrayList();
			views = new ArrayList();
			selected = null;
			snap_to_grid = true;
			memento = new Memento();
		}

		public void RegisterView(CView view)
		{
			views.Add(view);
			view.SetData(this);
			view.Invalidate();
		}

		public void RemoveView(CView view)
		{
			views.Remove(view);
		}

		public void UpdateViews()
		{
			UpdateViews(Updates.Full);
		}

		public void UpdateViews(Updates update)
		{
			foreach(CView view in views)
			{
				view.UpdateView(update);
			}
		}

		public void Resize(float factor)
		{
			Vector3 average = new Vector3(0f, 0f, 0f);
//			int num = 0;
//			foreach(CFigure f in figures)
//			{
//				num += f.vertices.Count;
//			}
//
//			float a = 1f / num;
//			foreach(CFigure f in figures)
//			{
//				foreach(CVertex v in f.vertices)
//				{
//					average += v.position * a;
//				}
//			}

			foreach(CFigure f in figures)
			{
				foreach(CVertex v in f.vertices)
				{
					v.position = (v.position - average) * factor
						+ average;
				}
			}
		}

		public Vector3 CountBoundingBox()
		{
			if(figures == null) return new Vector3(0f, 0f, 0f);
			if(figures.Count == 0) return new Vector3(0f, 0f, 0f);
			Vector3 ret = ((figures[0] as CFigure).vertices[0]
				as CVertex).position;
			Vector3 min = ret, max = ret;

			foreach(CFigure f in figures)
			{
				foreach(CVertex v in f.vertices)
				{
					min = Vector3.Minimize(min, v.position);
					max = Vector3.Maximize(max, v.position);
				}
			}

			ret = max - min;
			return ret;
		}

	} // End of class CModel

	public enum Updates
	{
		Full = 0,
		Move,
		Selection
	}
}
