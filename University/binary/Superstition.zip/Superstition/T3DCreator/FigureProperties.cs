using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;


namespace T3DCreator
{
	/// <summary>
	/// Summary description for FigureProperties.
	/// </summary>
	public class FigureProperties : System.Windows.Forms.Form
	{
		private T3DCreatorWindows.ColorDisplay colorDisplay1;
		private T3DCreatorWindows.ColorDisplay colorDisplay2;
		private T3DCreatorWindows.ColorDisplay colorDisplay3;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.NumericUpDown numericUpDown2;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FigureProperties()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.colorDisplay1 = new T3DCreatorWindows.ColorDisplay();
			this.colorDisplay2 = new T3DCreatorWindows.ColorDisplay();
			this.colorDisplay3 = new T3DCreatorWindows.ColorDisplay();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
			this.SuspendLayout();
			// 
			// colorDisplay1
			// 
			this.colorDisplay1.Color = System.Drawing.Color.White;
			this.colorDisplay1.Label = "Ambient";
			this.colorDisplay1.Location = new System.Drawing.Point(8, 8);
			this.colorDisplay1.Name = "colorDisplay1";
			this.colorDisplay1.Size = new System.Drawing.Size(144, 56);
			this.colorDisplay1.TabIndex = 0;
			this.colorDisplay1.ChangeEvent += new T3DCreatorWindows.ColorChanged(this.ChangeAmbientColor);
			// 
			// colorDisplay2
			// 
			this.colorDisplay2.Color = System.Drawing.Color.White;
			this.colorDisplay2.Label = "Diffuse";
			this.colorDisplay2.Location = new System.Drawing.Point(8, 72);
			this.colorDisplay2.Name = "colorDisplay2";
			this.colorDisplay2.Size = new System.Drawing.Size(144, 56);
			this.colorDisplay2.TabIndex = 1;
			this.colorDisplay2.ChangeEvent += new T3DCreatorWindows.ColorChanged(this.ChangeDiffuseColor);
			// 
			// colorDisplay3
			// 
			this.colorDisplay3.Color = System.Drawing.Color.Black;
			this.colorDisplay3.Label = "Emissive";
			this.colorDisplay3.Location = new System.Drawing.Point(8, 136);
			this.colorDisplay3.Name = "colorDisplay3";
			this.colorDisplay3.Size = new System.Drawing.Size(144, 56);
			this.colorDisplay3.TabIndex = 2;
			this.colorDisplay3.ChangeEvent += new T3DCreatorWindows.ColorChanged(this.ChangeEmissiveColor);
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.DecimalPlaces = 3;
			this.numericUpDown1.Location = new System.Drawing.Point(200, 168);
			this.numericUpDown1.Maximum = new System.Decimal(new int[] {
																		   1000,
																		   0,
																		   0,
																		   0});
			this.numericUpDown1.Minimum = new System.Decimal(new int[] {
																		   1,
																		   0,
																		   0,
																		   65536});
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(96, 20);
			this.numericUpDown1.TabIndex = 3;
			this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numericUpDown1.Value = new System.Decimal(new int[] {
																		 100,
																		 0,
																		 0,
																		 0});
			this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(152, 168);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(40, 24);
			this.label1.TabIndex = 4;
			this.label1.Text = "Zoom:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 32);
			this.label2.TabIndex = 5;
			this.label2.Text = "Automatic Texture Arranging";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(160, 48);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(56, 24);
			this.button1.TabIndex = 6;
			this.button1.Text = "Sphere";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 200);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(128, 24);
			this.label3.TabIndex = 7;
			this.label3.Text = "Maximum Edge Length:";
			// 
			// numericUpDown2
			// 
			this.numericUpDown2.DecimalPlaces = 3;
			this.numericUpDown2.Increment = new System.Decimal(new int[] {
																			 1,
																			 0,
																			 0,
																			 65536});
			this.numericUpDown2.Location = new System.Drawing.Point(136, 200);
			this.numericUpDown2.Maximum = new System.Decimal(new int[] {
																		   1,
																		   0,
																		   0,
																		   0});
			this.numericUpDown2.Minimum = new System.Decimal(new int[] {
																		   1,
																		   0,
																		   0,
																		   131072});
			this.numericUpDown2.Name = "numericUpDown2";
			this.numericUpDown2.Size = new System.Drawing.Size(80, 20);
			this.numericUpDown2.TabIndex = 8;
			this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.numericUpDown2.Value = new System.Decimal(new int[] {
																		 5,
																		 0,
																		 0,
																		 65536});
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(224, 200);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(72, 24);
			this.button2.TabIndex = 9;
			this.button2.Text = "Tessellate";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(224, 48);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(64, 24);
			this.button3.TabIndex = 10;
			this.button3.Text = "Random";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// FigureProperties
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(304, 230);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.numericUpDown2);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.numericUpDown1);
			this.Controls.Add(this.colorDisplay3);
			this.Controls.Add(this.colorDisplay2);
			this.Controls.Add(this.colorDisplay1);
			this.Name = "FigureProperties";
			this.Text = "FigureProperties";
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private float last_factor;

		private CFigure figure;
		public CFigure Figure
		{
			get{ return figure; }
			set
			{ 
				figure = value;
				last_factor = 1f;
				colorDisplay1.Color = Color.FromArgb(figure.ambient_color);
				colorDisplay2.Color = Color.FromArgb(figure.diffuse_color);
				colorDisplay3.Color = Color.FromArgb(figure.emissive_color);
			}
		}

		private CModel model;
		public CModel Model
		{
			get { return model; }
			set { model = value; }
		}

		private void ChangeAmbientColor(Color color)
		{
			int _color = color.ToArgb();
			model.Executor.Push(Operation.OpChangeFigureProperty(
				model, 
				figure, 
				_color, 
				figure.diffuse_color, 
				figure.emissive_color));
			model.UpdateViews(Updates.Selection);
		}

		private void ChangeDiffuseColor(Color color)
		{
			int _color = color.ToArgb();
			model.Executor.Push(Operation.OpChangeFigureProperty(
				model, 
				figure, 
				figure.ambient_color, 
				_color, 
				figure.emissive_color));
			model.UpdateViews(Updates.Selection);
		}
		
		private void ChangeEmissiveColor(Color color)
		{
			int _color = color.ToArgb();
			model.Executor.Push(Operation.OpChangeFigureProperty(
				model, 
				figure, 
				figure.ambient_color, 
				figure.diffuse_color, 
				_color));
			model.UpdateViews(Updates.Selection);
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			e.Cancel = true;
			this.Hide();
		}

		private void numericUpDown1_ValueChanged(object sender, System.EventArgs e)
		{
			float factor = (float)(sender as NumericUpDown).Value / 100f;
			model.Executor.Push(Operation.OpZoom(
				model, figure, factor / last_factor));
			model.UpdateViews(Updates.Move);
			last_factor = factor;
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			figure.SphereTexture();
			model.Executor.Clear();
			model.UpdateViews(Updates.Selection);
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			float max_edge = (float)numericUpDown2.Value;
			figure.Tessellate(max_edge, model);
			model.Executor.Clear();
			model.UpdateViews(Updates.Full);
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			figure.RandomTexture();
			model.Executor.Clear();
			model.UpdateViews(Updates.Selection);
		}

	}
}
