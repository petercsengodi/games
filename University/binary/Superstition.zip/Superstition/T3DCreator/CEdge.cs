using System;
using System.Collections;

using Microsoft.DirectX;

namespace T3DCreator
{
	/// <summary>
	/// Summary description for CEdge.
	/// </summary>
	public class CEdge : IPart
	{
		public CVertex from, to;
		public CTriangle triangle;

		private CEdge()
		{
			this.from = null;
			this.to = null;
		}

		public CEdge(CVertex from, CVertex to)
		{
			this.from = from;
			this.to = to;
		}

		public override string ToString()
		{
			if(from == null) return base.ToString();
			return "Edge (" + from.position.X.ToString() + ";" + 
				from.position.Y.ToString() + ";" + 
				from.position.Z.ToString() + ") -> (" + 
				to.position.X.ToString() + ";" +
				to.position.Y.ToString() + ";" + 
				to.position.Z.ToString() + ")";
		}

		public float Length()
		{
			return (from.position - to.position).Length();
		}

		public DiscardResult Split(CFigure figure, CModel model)
		{
			DiscardResult ret = new DiscardResult();
			ret.old_triangles = new CTriangle[2];
			ret.old_vertices = new CVertex[0];
			ret.new_triangles = new CTriangle[4];
			ret.new_vertices = new CVertex[1];

			// Search for vertices, edges, triangles
			CVertex from = this.from;
			CVertex to = this.to;
			CEdge other = null; // Must be an other edge, too
			CVertex this_3rd = null, other_3rd = null;
			
			foreach(CEdge e in from.edges)
			{
				if(e.Equals(this)) continue;
				if(to.edges.IndexOf(e) >= 0)
				{
					other = e;
					break;
				}
			}

			foreach(CVertex v in this.triangle.vertices)
			{
				if(!v.Equals(from) && !v.Equals(to))
				{
					this_3rd = v;
					break;
				}
			}

			foreach(CVertex v in other.triangle.vertices)
			{
				if(!v.Equals(from) && !v.Equals(to))
				{
					other_3rd = v;
					break;
				}
			}

			// Remove two triangles

			figure.triangles.Remove(this.triangle);
			ret.old_triangles[0] = this.triangle;
			foreach(CVertex v in this.triangle.vertices)
			{
				v.triangles.Remove(this.triangle);
			}
			foreach(CEdge e in this.triangle.edges)
			{
				e.from.edges.Remove(e);
				e.to.edges.Remove(e);
			}

			figure.triangles.Remove(other.triangle);
			ret.old_triangles[1] = other.triangle;
			foreach(CVertex v in other.triangle.vertices)
			{
				v.triangles.Remove(other.triangle);
			}
			foreach(CEdge e in other.triangle.edges)
			{
				e.from.edges.Remove(e);
				e.to.edges.Remove(e);
			}

			// the two vertices must have been neighbours

			to.neighbours.Remove(from);
			from.neighbours.Remove(to);

			// get new vertex

			Vector3 new_pos = new Vector3();
			new_pos.X = (from.position.X + to.position.X) / 2f;
			new_pos.Y = (from.position.Y + to.position.Y) / 2f;
			new_pos.Z = (from.position.Z + to.position.Z) / 2f;
	
			if(model.SnapToGrid)
			{
				new_pos.X = (float)(Math.Round(new_pos.X / model.grid_step) * model.grid_step);
				new_pos.Y = (float)(Math.Round(new_pos.Y / model.grid_step) * model.grid_step);
				new_pos.Z = (float)(Math.Round(new_pos.Z / model.grid_step) * model.grid_step);
			}

			Vector2 new_tex = new Vector2();
			new_tex.X = (from.texture_coordinates.X + to.texture_coordinates.X) / 2f;
			new_tex.Y = (from.texture_coordinates.Y + to.texture_coordinates.Y) / 2f;

			CVertex n = new CVertex(new_pos);
			n.texture_coordinates = new_tex;
			figure.vertices.Add(n);
			ret.new_vertices[0] = n;

			// create 4 new triangles

			CTriangle t;
			t = new CTriangle(this.from, n, this_3rd);
			figure.triangles.Add(t);
			ret.new_triangles[0] = t;
			t = new CTriangle(n, this.to, this_3rd);
			figure.triangles.Add(t);
			ret.new_triangles[1] = t;
			t = new CTriangle(other.from, n, other_3rd);
			figure.triangles.Add(t);
			ret.new_triangles[2] = t;
			t = new CTriangle(n, other.to, other_3rd);
			figure.triangles.Add(t);
			ret.new_triangles[3] = t;

			return ret;
		}

		#region IPart Members

		public void move(Microsoft.DirectX.Vector3 direction)
		{
			this.to.move(direction);
			this.from.move(direction);
		}

		public void moveTexture(Vector2 direction)
		{
			this.to.moveTexture(direction);
			this.from.moveTexture(direction);
		}

		#endregion

		public static object GetNullInstance()
		{
			return new CEdge();
		}

	}
}
