using System;
using System.Drawing;
using System.Collections;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace Engine
{

	/// <summary>
	/// Class for Renderable Elements constructed by primitives.
	/// </summary>
	public abstract class Element : IDisposable
	{
		protected Engine engine;
		private static Vector3 vup = new Vector3(0f, 1f, 0f);
		protected bool shadow = true;
		protected Matrix inverz = Matrix.Identity;

		/// <summary>
		/// Turn on/off element shadow. (True as default.)
		/// </summary>
		public bool Shadow
		{
			get{ return shadow; }
			set{ shadow = value; }
		}

		/// <summary>
		/// Class for Renderable Elements.
		/// </summary>
		/// <param name="_device">Device used by DirectX Engine.</param>
		public Element(Engine _engine)
		{
			engine = _engine;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		/// <param name="position">Position of the Object in the World.</param>
		/// <param name="orientation">Orientation of the Oject in the World.</param>
		public void Render(Vector3 translation, Vector3 orientation)
		{
			Matrix world;
			inverz = Matrix.LookAtLH(translation, 
				Vector3.Add(translation, orientation), vup);
			world = inverz;
			world.Invert();
			engine.Device.Transform.World = world;

			Render();

			engine.Device.Transform.World = Matrix.Identity;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		/// <param name="world">World matrix for element.</param>
		public void Render(Matrix world)
		{
			inverz = world;
			inverz.Invert();
			engine.Device.Transform.World = world;
			Render();
			engine.Device.Transform.World = Matrix.Identity;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		/// <param name="translation">Translation Vector.</param>
		public void Render(Vector3 translation)
		{
			engine.Device.Transform.World = Matrix.Translation(translation);
			inverz = Matrix.Translation(-translation);
			
			Render();

			engine.Device.Transform.World = Matrix.Identity;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		/// <param name="translation">Position of the Object in the World.</param>
		/// <param name="xRotation">Rotation of the Object at Axis X in the World.</param>
		/// <param name="yRotation">Rotation of the Object at Axis Y in the World.</param>
		/// <param name="zRotation">Rotation of the Object at Axis Z in the World.</param>
		public void Render(Vector3 translation, float xRotation, float yRotation, float zRotation)
		{
			engine.Device.Transform.World = 
				Matrix.Multiply(Matrix.RotationX(xRotation),
				Matrix.Multiply(Matrix.RotationY(yRotation),
				Matrix.Multiply(Matrix.RotationZ(zRotation),
				Matrix.Translation(translation))));

			inverz = Matrix.Multiply(Matrix.Translation(-translation),
				Matrix.Multiply(Matrix.RotationZ(-zRotation),
				Matrix.Multiply(Matrix.RotationY(-yRotation),
				Matrix.RotationX(-xRotation))));
			
			Render();

			engine.Device.Transform.World = Matrix.Identity;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		public abstract void Render();

		/// <summary>
		/// Rendering the shadow volume of an element.
		/// </summary>
		public virtual void RenderShadow(){}

		/// <summary>
		/// Disposes this element. (Gets itself out of Engine's 
		/// dispose list)
		/// </summary>
		abstract public void Dispose();

	} // End of Element

	/// <summary>
	/// Help class for Meshes.
	/// </summary>
	class ShadowSquare
	{
		public int triangle1, triangle2;
		public Vector3 v11, v12, v21, v22;

		public ShadowSquare(int triangle1, Vector3 v11, Vector3 v12,
			int triangle2, Vector3 v21, Vector3 v22)
		{
			this.triangle1 = triangle1;
			this.triangle2 = triangle2;
			this.v11 = v11;
			this.v12 = v12;
			this.v21 = v21;
			this.v22 = v22;
		}
	}

	/// <summary>
	/// Class for meshes.
	/// </summary>
	public class MeshElement : Element
	{
		private Material[] mats;
		private Texture[] texs;
		private Mesh mesh/*, shadowMesh2*/;
		private int texes = 0;
		private AttributeRange[] attributes;

		// For mesh shadow
//		private static float e = 0.000001f;
		private VertexBuffer shadowMesh;
		private ArrayList squares;
		private Vector3[] normals;
		private int shadowSquares;

		// TODO: Index Buffer Solution
		//		private IndexBuffer shadowMeshIndicies;

		public MeshElement(Engine engine, TextureLibrary lib, string filename, bool shadow)
			: base(engine)
		{
			ExtendedMaterial[] exmats;
			mesh = Mesh.FromFile(@"..\meshes\" + filename, 
				MeshFlags.SystemMemory, engine.Device, out exmats);

			texs = new Texture[exmats.Length];
			mats = new Material[exmats.Length];
			this.shadow = shadow;

			for(int i = 0; i < exmats.Length; i++)
			{
				if(exmats[i].TextureFilename != null) texs[i] = lib.getTexture(@"..\textures\mesh_textures\" + exmats[i].TextureFilename);
				mats[i] = exmats[i].Material3D;
				mats[i].Ambient = exmats[i].Material3D.Diffuse;
			}

			texes = exmats.Length;
			engine.AddToDisposeList(mesh);
			attributes = mesh.GetAttributeTable();

			if(shadow)
			{
				// Calculates shadow volume
				Mesh temp = mesh.Clone( MeshFlags.Use32Bit, 
					CustomVertex.PositionOnly.Format, engine.Device);
				squares = new ArrayList();
			
				CustomVertex.PositionOnly[] vertices = (CustomVertex.PositionOnly[])temp.LockVertexBuffer(
					typeof(CustomVertex.PositionOnly), LockFlags.ReadOnly, temp.NumberVertices);
				int[] indices = (int[])temp.LockIndexBuffer(typeof(System.Int32), 
					LockFlags.ReadOnly, temp.NumberFaces * 3);

				int l, m, n, o;
				normals = new Vector3[temp.NumberFaces];
				Vector3[] t1 = new Vector3[3], t2 = new Vector3[3];
				
				// initializing error detector
				bool[,] edges = new bool[temp.NumberFaces, 4]; 
				// shows which edge of the triangle is "volumed"
				// forth edge is true, if it's a null-triangle
				for(int i = 0; i < temp.NumberFaces; i++)
				{ // initializing edge array with false value
					for(int j = 0; j < 4; j++) edges[i,j] = false;
				}

				// counting normals of the triangles
				for(int i = 0; i < temp.NumberFaces; i++)
				{
					// extracting vertex position informations
					t1[0] = vertices[indices[i * 3]].Position;
					t1[1] = vertices[indices[i * 3 + 1]].Position;
					t1[2] = vertices[indices[i * 3 + 2]].Position;
					// if it is a null_triangle, than it shouldn't be represented in the volume
					if((t1[0] == t1[1]) || (t1[1] == t1[2]) || (t1[0] == t1[2]))
					{
						edges[i,3] = true; // this means this triangle is null
						continue; // don't count anything
					}

					// counting normal vector for triangle's true face
					normals[i] = Vector3.Normalize(Vector3.Cross(t1[1] - t1[0], t1[2] - t1[0]));

					// Just for testing ...
//					squares.Add(new ShadowSquare(i+1, t1[2], t1[1], i+1, t1[0], t1[0]));
				}

				// creating list of squares
				for(int i = 0; i < temp.NumberFaces; i++)
				{
					// if null-triangle, don't care with it
					if(edges[i,3]) continue;

					// extracting vertex position information
					t1[0] = vertices[indices[i * 3]].Position;
					t1[1] = vertices[indices[i * 3 + 1]].Position;
					t1[2] = vertices[indices[i * 3 + 2]].Position;

					for(int j = i + 1; j < temp.NumberFaces; j++)
					{
						// if null-triangle, don't care with it
						if(edges[j,3]) continue;

						// extracting vertex position information
						t2[0] = vertices[indices[j * 3]].Position;
						t2[1] = vertices[indices[j * 3 + 1]].Position;
						t2[2] = vertices[indices[j * 3 + 2]].Position;

						// trying two triangles to eachothers
						for(int k = 0; k < 9; k++)
						{
							l = k / 3; m = (l + 1) % 3;
							n = k % 3; o = (n + 1) % 3;

							if((t1[l] == t2[o]) && (t1[m] == t2[n]))
							{
								// adding a new volume square
								squares.Add(new ShadowSquare(i+1, t1[l], t1[m], j+1, t2[n], t2[o]));
								// marking edges represented in the volume
								edges[i, l] = true; edges[j, n] = true;
							}
						} // end for k

					} // end for j
				} // end for i

				for(int i = 0; i < temp.NumberFaces; i++)
				{
					// null-triangle, don't care with it
					if(edges[i,3]) continue;

					for(int j = 0; j < 3; j++)
					{
						if(edges[i,j]) continue; // if marked, triangle is o.k.
						// extracting vertex position information
						t1[0] = vertices[indices[i * 3]].Position;
						t1[1] = vertices[indices[i * 3 + 1]].Position;
						t1[2] = vertices[indices[i * 3 + 2]].Position;

						// create a side element closing the volume body
						squares.Add(new ShadowSquare(
							i+1, t1[j], t1[(j+1)%3], 
							-(i+1), t1[j], t1[(j+1)%3]));
					} // end for j
				} // end for i

				temp.UnlockVertexBuffer();
				temp.UnlockIndexBuffer();
				temp.Dispose();
//				shadowMesh2 = temp;

				shadowMesh = new VertexBuffer(typeof(CustomVertex.PositionNormal), 
					squares.Count * 4, engine.Device, 0, 
					CustomVertex.PositionOnly.Format, Pool.Managed);
	
				shadowMesh.Created += new EventHandler(shadowMesh_Created);
				shadowMesh_Created(shadowMesh, null);
				engine.AddToDisposeList(shadowMesh);
				shadowSquares = squares.Count;
			} 
			else 
			{
				shadowMesh = null;
				squares = null;
				normals = null;
				shadowSquares = 0;
			}
		}

		public void SetAttrib(Color color)
		{
			for(int i = 0; i < texes; i++)
				mats[i].Emissive = color;
		}

		public override void Render()
		{
			if(engine.IsShadowRendering)
			{ 
				if(shadow && (shadowMesh != null))
				{ 
					if(engine.Options.renderMeshShadow) 
						engine.RenderVolume(shadowMesh, shadowSquares, mesh, attributes.Length, inverz);
//						OldRenderShadow();
					return; 
				}
			}
	
//			if(shadow)
//			{
//				engine.RenderVolume(shadowMesh, shadowSquares, mesh, attributes.Length, inverz); 
//				return;
//			}


			Material temp = engine.Device.Material;
			for(int i = 0; i < attributes.Length; i++)
			{
				if(texs[i] != null) engine.Device.SetTexture(0, texs[i]);
				engine.Device.Material = mats[i];
				mesh.DrawSubset(i);
			}

			engine.Device.Material = temp;

//			if(shadow) engine.RenderVolume(shadowMesh, shadowSquares, mesh, attributes.Length, inverz);
		}

		public override void Dispose()
		{
			engine.RemoveFromDisposeList(mesh);
			engine.RemoveFromDisposeList(shadowMesh);
			mesh.Dispose();
			if(shadowMesh != null) shadowMesh.Dispose();
		}

		private void shadowMesh_Created(object sender, EventArgs e)
		{
			CustomVertex.PositionNormal[] vs = (CustomVertex.PositionNormal[])shadowMesh.Lock(0, 
				typeof(CustomVertex.PositionNormal), LockFlags.Discard, squares.Count * 4);
			Vector3 n1, n2;

			for(int i = 0; i < squares.Count; i++)
			{
				ShadowSquare q = squares[i] as ShadowSquare;
				n1 = (q.triangle1 > 0) ? normals[q.triangle1-1] : -normals[-q.triangle1-1];
				n2 = (q.triangle2 > 0) ? normals[q.triangle2-1] : -normals[-q.triangle2-1];
				vs[i*4  ] = new CustomVertex.PositionNormal(q.v22, n2);
				vs[i*4+1] = new CustomVertex.PositionNormal(q.v21, n2);
				vs[i*4+2] = new CustomVertex.PositionNormal(q.v11, n1);
				vs[i*4+3] = new CustomVertex.PositionNormal(q.v12, n1);
			}

			shadowMesh.Unlock();
		}

		/*
		public void OldRenderShadow()
		{
			int[] indices = (int[])shadowMesh2.LockIndexBuffer(typeof(System.Int32), 
				LockFlags.ReadOnly, shadowMesh2.NumberFaces * 3);
			CustomVertex.PositionOnly[] vertices =(CustomVertex.PositionOnly[])
				shadowMesh2.LockVertexBuffer(typeof(CustomVertex.PositionOnly),
				LockFlags.ReadOnly, shadowMesh2.NumberVertices);
			Vector3 a, b, c;
			
			for(int idx, i = 0; i < shadowMesh2.NumberFaces; i++)
			{
				idx = indices[i * 3];
				a = vertices[idx].Position;
				idx = indices[i * 3 + 1];
				b = vertices[idx].Position;
				idx = indices[i * 3 + 2];
				c = vertices[idx].Position;
				engine.RenderVolume(a, b, c);
				engine.RenderVolume(c, b, a);
			}

			shadowMesh2.UnlockVertexBuffer();
			shadowMesh2.UnlockIndexBuffer();

		}*/

		public float Radius()
		{
			float ret = 0f;
			Vector3 average = new Vector3(0f, 0f, 0f);

			CustomVertex.PositionNormalTextured[] array =
				(CustomVertex.PositionNormalTextured[])
				mesh.LockVertexBuffer(
				typeof(CustomVertex.PositionNormalTextured),
				LockFlags.ReadOnly,
				mesh.NumberVertices);

			for(int i = 0; i < array.Length; i++)
			{
				average += array[i].Position * 
					(1f / mesh.NumberVertices);
			}

			float length;
			for(int i = 0; i < array.Length; i++)
			{
				length = (array[i].Position - average).Length();
				ret = Math.Max(ret, length);
			}

			mesh.UnlockVertexBuffer();
			return ret;
		}

		public Vector3[] Borders()
		{			
			Vector3[] corners = null;

			CustomVertex.PositionNormalTextured[] array =
				(CustomVertex.PositionNormalTextured[])
				mesh.LockVertexBuffer(
				typeof(CustomVertex.PositionNormalTextured),
				LockFlags.ReadOnly,
				mesh.NumberVertices);

			if(array.Length > 0)
			{
				corners = new Vector3[2];
				corners[0] = array[0].Position;
				corners[1] = array[0].Position;

				for(int i = 1; i < array.Length; i++)
				{
					corners[0] = Vector3.Minimize(
						corners[0], array[i].Position);
					corners[1] = Vector3.Maximize(
						corners[1], array[i].Position);
				}
			}

			mesh.UnlockVertexBuffer();
			return corners;
		}

	} // End of class Mesh Element

	/// <summary>
	/// Class for text meshes. Sholud be used only for the menu.
	/// </summary>
	public class MeshText : Element
	{
		private Material material;
		private Mesh mesh;
		private GlyphMetricsFloat[] metrics;
		private float extrusion;
		private Vector3 center = new Vector3(0f, 0f, 0f);
		public Vector3 Center { get { return center; } }

		public MeshText(Engine engine, System.Drawing.Font font, string text, float deviation, float extrusion)
			: base(engine)
		{
			mesh = Mesh.TextFromFont(engine.Device, font, text, deviation, extrusion, out metrics);
			engine.AddToDisposeList(mesh);
			material = new Material();
			material.Ambient = Color.White;
			material.Diffuse = Color.White;

			this.extrusion = extrusion;

			for(int i = 0; i < metrics.Length; i++)
			{
				center.X += metrics[i].BlackBoxX;
				center.Y = Math.Max(center.Y, metrics[i].BlackBoxY);
			}
			center.Z = -extrusion / 2f;
		}

		public override void Render()
		{
			if(engine.IsShadowRendering)
			{ 
				if(shadow)
				{ 
					if(engine.Options.renderMeshShadow) RenderShadow();
					return; 
				}
			}
			
//			RenderShadow(); return; 

			Material temp = engine.Device.Material;
			engine.Device.Material = material;
			mesh.DrawSubset(0);
			engine.Device.Material = temp;
		}

		public override void Dispose()
		{
			engine.RemoveFromDisposeList(mesh);
			mesh.Dispose();
		}

		public override void RenderShadow()
		{
			Matrix temp = engine.Device.Transform.World;
			Matrix temp2 = Matrix.Identity;
			
			Vector3 light = engine.LightPosition; 
			Vector3 b = Vector3.TransformCoordinate(
				new Vector3(center.X, center.Y, 0f), 
				engine.Device.Transform.World);
			Vector3 a = Vector3.TransformCoordinate( 
				new Vector3(center.X, center.Y, -extrusion), 
				engine.Device.Transform.World);
			float l = (light - a).Length();
			float d = l / (20f + l);
			float z1 = a.Z, z2 = b.Z;

			temp2.M31 = (d - 1f) * light.X / (z2 - z1);
			temp2.M32 = (d - 1f) * light.Y / (z2 - z1);
			temp2.M33 = (d - 1f) * light.Z / (z2 - z1);
			temp2.M34 = (d - 1f) / (z2 - z1);
			temp2.M41 = - z1 * (d - 1f) * light.X / (z2 - z1);
			temp2.M42 = - z1 * (d - 1f) * light.Y / (z2 - z1);
			temp2.M43 = - z1 * (d - 1f) * light.Z / (z2 - z1);
			temp2.M44 = 1 - z1 * (d - 1f) / (z2 - z1);
			engine.Device.Transform.World = temp * temp2;


			engine.Device.RenderState.CullMode = Cull.CounterClockwise;
//			Device.RenderState.CullMode = Cull.CounterClockwise;
			engine.Device.RenderState.StencilPass = StencilOperation.Increment;
			mesh.DrawSubset(0);

			engine.Device.RenderState.CullMode = Cull.Clockwise;
//			Device.RenderState.CullMode = Cull.Clockwise;
			engine.Device.RenderState.StencilPass = StencilOperation.Decrement;
			mesh.DrawSubset(0);

			engine.Device.RenderState.CullMode = Cull.CounterClockwise;
			engine.Device.Transform.World = temp;
		}

	}


	/// <summary>
	/// Class for Renderable Primitives.
	/// </summary>
	public abstract class Primitive : Element
	{
		protected Texture face = null;
		protected VertexBuffer buffer = null;
		protected int count, lock_index;
		protected bool foreign_buffer = false;

		protected bool notEffectedByLight = false;
		public bool NotEffectedByLight{ get { return notEffectedByLight; } set { notEffectedByLight = value; }}
		public int Count{ get { return count; } }

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="device">Device used by DirectX Engine.</param>
		public Primitive(Engine engine) : base(engine)
		{
			buffer = null;
			lock_index = 0;
			foreign_buffer = false;
		}

		/// <summary>
		/// Constructor with foreign buffer.
		/// </summary>
		/// <param name="engine"></param>
		/// <param name="buffer"></param>
		/// <param name="buffer_index"></param>
		public Primitive(Engine engine, VertexBuffer buffer) : base (engine)
		{
			this.buffer = buffer;
			foreign_buffer = true;
			lock_index = buffer.SizeInBytes;
		}

		/// <summary>
		/// Recreating Primitive.
		/// </summary>
		public virtual void ReCreate()
		{
			if(face == null) return;

			if(!foreign_buffer)
			{
				buffer = new VertexBuffer(typeof(CustomVertex.PositionNormalTextured),
					count, engine.Device, 0, CustomVertex.PositionNormalTextured.Format, Pool.Managed);
				engine.AddToDisposeList(buffer);
			}
			
			buffer.Created += new EventHandler(Initialize);
			Initialize(buffer, null);
		}

		/// <summary>
		/// Initializing Primitive.
		/// </summary>
		/// <param name="buf">VertexBuffer.</param>
		/// <param name="ea">Not Used.</param>
		abstract public void Initialize(object buf, EventArgs ea);

		/// <summary>
		/// ReInitialization of Primitive.
		/// </summary>
		public virtual void ReInit(){ Initialize(buffer, null); }

		/// <summary>
		/// Dispose function.
		/// </summary>
		public override void Dispose()
		{
			engine.RemoveFromDisposeList(buffer);
			if(buffer != null) buffer.Dispose();
			buffer = null;
		}

	} // End of Primitive


	/// <summary>
	/// Class for a tessellated Plane with faces of six directions.
	/// </summary>
	public class EPlane : Primitive
	{
		protected Vector3 Min, Max;
		protected StaticVectorLibrary.Direction direction;
		protected int x, y, z;
		
		public StaticVectorLibrary.Direction Direction
		{
			get{ return direction; }
		}

		public EPlane(Engine engine, Vector3 MinVec, Vector3 MaxVec, 
			StaticVectorLibrary.Direction _direction, Texture _face) : base(engine)
		{
			Min = MinVec;
			Max = MaxVec;
			direction = _direction;
			face = _face;
			float STEP = engine.Options.detail;

			x = (int) Math.Ceiling((Max.X - Min.X) / STEP);
			y = (int) Math.Ceiling((Max.Y - Min.Y) / STEP);
			z = (int) Math.Ceiling((Max.Z - Min.Z) / STEP);
			
			if((direction == StaticVectorLibrary.Left) || (direction == StaticVectorLibrary.Right))
			{
				x = 1;
				count = (z + 1) * 2 * y /* For simplified version */ + 6;			
			}

			if((direction == StaticVectorLibrary.Front) || (direction == StaticVectorLibrary.Back))
			{
				z = 1;
				count = (x + 1) * 2 * y  /* For simplified version */ + 6;			
			}

			if((direction == StaticVectorLibrary.Top) || (direction == StaticVectorLibrary.Bottom))
			{
				y = 1;
				count = (x + 1) * 2 * z /* For simplified version */ + 6;			
			}

			ReCreate();
		}
									   
		public EPlane(Engine engine, Vector3 MinVec, Vector3 MaxVec, 
			StaticVectorLibrary.Direction _direction, Texture _face, VertexBuffer buffer) : base(engine, buffer)
		{
			Min = MinVec;
			Max = MaxVec;
			direction = _direction;
			face = _face;

			float STEP = engine.Options.detail;
			x = (int) Math.Ceiling((Max.X - Min.X) / STEP);
			y = (int) Math.Ceiling((Max.Y - Min.Y) / STEP);
			z = (int) Math.Ceiling((Max.Z - Min.Z) / STEP);
			
			if((direction == StaticVectorLibrary.Left) || (direction == StaticVectorLibrary.Right))
			{
				x = 1;
				count = (z + 1) * 2 * y /* For simplified version */ + 6;			
			}

			if((direction == StaticVectorLibrary.Front) || (direction == StaticVectorLibrary.Back))
			{
				z = 1;
				count = (x + 1) * 2 * y  /* For simplified version */ + 6;			
			}

			if((direction == StaticVectorLibrary.Top) || (direction == StaticVectorLibrary.Bottom))
			{
				y = 1;
				count = (x + 1) * 2 * z /* For simplified version */ + 6;			
			}

			
			ReCreate();
		}


		public override void Initialize(object buf, EventArgs ea)
		{
			GraphicsStream stream = buffer.Lock(lock_index, 0, 0);

			int i, j;
			float stepx = (Max.X - Min.X) / x, stepy = (Max.Y - Min.Y) / y, stepz = (Max.Z - Min.Z) / z;

			if(direction == StaticVectorLibrary.Left)
			{
				for(j = 0; j < y; j++)
				{
					for(i = 0; i <= z; i++)
					{
						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Max.X, Min.Y + (j + 1) * stepy, Min.Z + i * stepz),
							new Vector3(-1f, 0f, 0f),
							Min.Z + i * stepz, Min.Y + (j + 1) * stepy
							));

						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X, Min.Y + j * stepy, Min.Z + i * stepz),
							new Vector3(-1f, 0f, 0f),
							Min.Z + i * stepz, Min.Y + j * stepy
							));
					}
				}
			} // End of: Left

			if(direction == StaticVectorLibrary.Right)
			{
				for(j = 0; j < y; j++)
				{
					for(i = 0; i <= z; i++)
					{
						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X, Min.Y + j * stepy, Min.Z + i * stepz),
							new Vector3(1f, 0f, 0f),
							Min.Z + i * stepz, Min.Y + j * stepy
							));

						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Max.X, Min.Y + (j + 1) * stepy, Min.Z + i * stepz),
							new Vector3(1f, 0f, 0f),
							Min.Z + i * stepz, Min.Y + (j + 1) * stepy
							));
					}
				}
			} // End of: Right

			if(direction == StaticVectorLibrary.Front)
			{
				for(j = 0; j < y; j++)
				{
					for(i = 0; i <= x; i++)
					{
						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X + i * stepx, Min.Y + (j + 1) * stepy, Max.Z),
							new Vector3(0f, 0f, 1f),
							Min.X + i * stepx, Min.Y + (j + 1) * stepy
							));

						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X + i * stepx, Min.Y + j * stepy, Min.Z),
							new Vector3(0f, 0f, 1f),
							Min.X + i * stepx, Min.Y + j * stepy
							));
					}
				}
			} // End of: Front

			if(direction == StaticVectorLibrary.Back)
			{
				for(j = 0; j < y; j++)
				{
					for(i = 0; i <= x; i++)
					{
						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X + i * stepx, Min.Y + j * stepy, Min.Z),
							new Vector3(0f, 0f, -1f),
							Min.X + i * stepx, Min.Y + j * stepy
							));

						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X + i * stepx, Min.Y + (j + 1) * stepy, Max.Z),
							new Vector3(0f, 0f, -1f),
							Min.X + i * stepx, Min.Y + (j + 1) * stepy
							));
					}
				}
			} // End of: Back

			if(direction == StaticVectorLibrary.Top)
			{
				for(j = 0; j < z; j++)
				{
					for(i = 0; i <= x; i++)
					{
						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X + i * stepx, Max.Y, Min.Z  + j * stepz),
							new Vector3(0f, 1f, 0f),
							Min.X + i * stepx, Min.Z + j * stepz
							));

						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X + i * stepx, Min.Y, Min.Z + (j + 1) * stepz),
							new Vector3(0f, 1f, 0f),
							Min.X + i * stepx, Min.Z + (j + 1) * stepz
							));
					}
				}
			} // End of: Top

			if(direction == StaticVectorLibrary.Bottom)
			{
				for(j = 0; j < z; j++)
				{
					for(i = 0; i <= x; i++)
					{
						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X + i * stepx, Min.Y, Min.Z + (j + 1) * stepz),
							new Vector3(0f, -1f, 0f),
							Min.X + i * stepx, Min.Z + (j + 1) * stepz
							));

						stream.Write(new CustomVertex.PositionNormalTextured(
							new Vector3(Min.X + i * stepx, Max.Y, Min.Z  + j * stepz),
							new Vector3(0f, -1f, 0f),
							Min.X + i * stepx, Min.Z + j * stepz
							));
					}
				}
			} // End of: Bottom

			/* For simplified version */

			stream.Write(direction.SquarePoint(Min, Max, 0));
			stream.Write(direction.SquarePoint(Min, Max, 1));
			stream.Write(direction.SquarePoint(Min, Max, 2));
			stream.Write(direction.SquarePoint(Min, Max, 2));
			stream.Write(direction.SquarePoint(Min, Max, 3));
			stream.Write(direction.SquarePoint(Min, Max, 0));

			buffer.Unlock();
		}

		public override void Render()
		{
			if(engine.IsShadowRendering)
			{ 
				if(shadow){ RenderShadow(); return; }
			}
			if(face == null) return;

//			RenderShadow(); return;

			engine.Device.SetTexture(0, face);

			if(NotEffectedByLight && !(engine.IsLighted))
			{
				/* For simplified version */
				engine.Device.SetStreamSource(0, buffer, lock_index);
				engine.Device.VertexFormat = CustomVertex.PositionNormalTextured.Format;
				engine.Device.DrawPrimitives(PrimitiveType.TriangleList, count - 6, 2);
			} 
			else 
			{
				engine.Device.SetStreamSource(0, buffer, lock_index);
				engine.Device.VertexFormat = CustomVertex.PositionNormalTextured.Format;

				if((direction == StaticVectorLibrary.Left) || (direction == StaticVectorLibrary.Right))
				{
					for(int i = 0; i < y; i ++)
						engine.Device.DrawPrimitives(PrimitiveType.TriangleStrip, ((z+1) * 2) * i , z * 2);
				}

				else if((direction == StaticVectorLibrary.Front) || (direction == StaticVectorLibrary.Back))
				{
					for(int i = 0; i < y; i ++)
						engine.Device.DrawPrimitives(PrimitiveType.TriangleStrip, ((x+1) * 2) * i , x * 2);
				}

				else if((direction == StaticVectorLibrary.Top) || (direction == StaticVectorLibrary.Bottom))
				{
					for(int i = 0; i < z; i ++)
						engine.Device.DrawPrimitives(PrimitiveType.TriangleStrip, ((x+1) * 2) * i , x * 2);
				}
			}

			engine.Device.SetTexture(0, null);
		}

		public override void RenderShadow()
		{
			if(direction == StaticVectorLibrary.Left)
			{
				engine.RenderVolume(Min, new Vector3(Min.X, Min.Y, Max.Z), Max);
				engine.RenderVolume(Max, new Vector3(Min.X, Max.Y, Min.Z), Min);
				engine.RenderVolume(Min, new Vector3(Min.X, Max.Y, Min.Z), Max); // NOT CORRECT DIRECTION
				engine.RenderVolume(Max, new Vector3(Min.X, Min.Y, Max.Z), Min); // NOT CORRECT DIRECTION
			}

			if(direction == StaticVectorLibrary.Right)
			{
				engine.RenderVolume(Min, new Vector3(Min.X, Max.Y, Min.Z), Max);
				engine.RenderVolume(Max, new Vector3(Min.X, Min.Y, Max.Z), Min);
				engine.RenderVolume(Min, new Vector3(Min.X, Min.Y, Max.Z), Max); // NOT CORRECT DIRECTION
				engine.RenderVolume(Max, new Vector3(Min.X, Max.Y, Min.Z), Min); // NOT CORRECT DIRECTION
			}

			if(direction == StaticVectorLibrary.Front)
			{
				engine.RenderVolume(Min, new Vector3(Max.X, Min.Y, Min.Z), Max);
				engine.RenderVolume(Max, new Vector3(Min.X, Max.Y, Min.Z), Min);
				engine.RenderVolume(Min, new Vector3(Min.X, Max.Y, Min.Z), Max); // NOT CORRECT DIRECTION
				engine.RenderVolume(Max, new Vector3(Max.X, Min.Y, Min.Z), Min); // NOT CORRECT DIRECTION
			}

			if(direction == StaticVectorLibrary.Back)
			{
				engine.RenderVolume(Min, new Vector3(Min.X, Max.Y, Min.Z), Max);
				engine.RenderVolume(Max, new Vector3(Max.X, Min.Y, Min.Z), Min);
				engine.RenderVolume(Min, new Vector3(Max.X, Min.Y, Min.Z), Max); // NOT CORRECT DIRECTION
				engine.RenderVolume(Max, new Vector3(Min.X, Max.Y, Min.Z), Min); // NOT CORRECT DIRECTION
			}

			if(direction == StaticVectorLibrary.Top)
			{
				engine.RenderVolume(Min, new Vector3(Min.X, Min.Y, Max.Z), Max);
				engine.RenderVolume(Max, new Vector3(Max.X, Min.Y, Min.Z), Min);
				engine.RenderVolume(Min, new Vector3(Max.X, Min.Y, Min.Z), Max); // NOT CORRECT DIRECTION
				engine.RenderVolume(Max, new Vector3(Min.X, Min.Y, Max.Z), Min); // NOT CORRECT DIRECTION
			}

			if(direction == StaticVectorLibrary.Bottom)
			{
				engine.RenderVolume(Min, new Vector3(Max.X, Min.Y, Min.Z), Max);
				engine.RenderVolume(Max, new Vector3(Min.X, Min.Y, Max.Z), Min);
				engine.RenderVolume(Min, new Vector3(Min.X, Min.Y, Max.Z), Max); // NOT CORRECT DIRECTION
				engine.RenderVolume(Max, new Vector3(Max.X, Min.Y, Min.Z), Min); // NOT CORRECT DIRECTION
			}
		}


	}

	/// <summary>
	/// A Triangle that's tesselated, keeping the culling.
	/// </summary>
	public class ETesselatedTriangle : Primitive
	{
		private Vector3 a, b, c, normal;
		private float lAB, lAC, lBC;
		private int n;

		public ETesselatedTriangle(Engine engine, Vector3 a, Vector3 b, Vector3 c, Texture face) : base(engine)
		{
			this.a = a;
			this.b = b;
			this.c = c;
			this.face = face;
			Construct();
		}

		public ETesselatedTriangle(Engine engine, VertexBuffer buffer, Vector3 a, Vector3 b, Vector3 c, Texture face) : base(engine, buffer)
		{
			this.a = a;
			this.b = b;
			this.c = c;
			this.face = face;
			Construct();
		}

		private void Construct()
		{
			Vector3 AB = b - a, AC = c - a, BC = c - b;
			float l = engine.Options.detail;
			n = Math.Max( (int)Math.Ceiling(AB.Length() / l) , (int)Math.Ceiling(AC.Length() / l));
			n = Math.Max( (int)Math.Ceiling(BC.Length() / l) , n);
			lAB = AB.Length() / n;
			lAC = AC.Length() / n;
			lBC = BC.Length() / n;

			count = 0;
			int prev = 0, next = 1;
			for(int i = 0; i < n; i++)
			{
				prev = next;
				next++;
				count += prev + next;
			}

			count += 3;
			normal = Vector3.Cross(AB, AC);
			normal.Normalize();

			ReCreate();
		}

		public override void Initialize(object buf, EventArgs ea)
		{
			GraphicsStream stream = ((VertexBuffer)buf).Lock(lock_index, 0, 0);
			Vector3 AB = b - a, AC = c - a, BC = c - b, tB, tC, tX;
			Vector3[] pre_array, next_array;
			pre_array = new Vector3[1];
			pre_array[0] = a;

			//	Counting matrix for Textures
            Matrix m,
				t1 = Matrix.Identity, 
				t2 = Matrix.Identity;

			t2.M11 =  normal.X;
			t2.M13 = -normal.Z;
			t2.M31 =  normal.Z;
			t2.M33 =  normal.X;

			Vector3 temp = Vector3.TransformCoordinate(normal, t2);

			t1.M11 =  temp.X;
			t1.M12 = -temp.Y;
			t1.M21 =  temp.Y;
			t1.M22 =  temp.X;

			m = Matrix.Multiply(t2, t1);

			for(int i = 1; i <= n; i++)
			{
				tB = ((float)i / (float)n) * (b - a) + a;
				tC = ((float)i / (float)n) * (c - a) + a;
				
				next_array = new Vector3[i+1];
				for(int j = 0; j <= i; j++)
				{
					next_array[j] = tB * ((float)(i-j) / (float)i) + tC * ((float)j / (float)i);
				}

				tX = Vector3.TransformCoordinate(next_array[i], m);
				stream.Write(new CustomVertex.PositionNormalTextured(
					next_array[i], normal, tX.Z, tX.Y
					));

				for(int j = i - 1; j >= 0; j--)
				{
					tX = Vector3.TransformCoordinate(pre_array[j], m);
					stream.Write(new CustomVertex.PositionNormalTextured(
						pre_array[j], normal, tX.Z, tX.Y
						));

					tX = Vector3.TransformCoordinate(next_array[j], m);
					stream.Write(new CustomVertex.PositionNormalTextured(
						next_array[j], normal, tX.Z, tX.Y
						));
				}

				pre_array = next_array;
			}
			
			tX = Vector3.TransformCoordinate(a, m);
			stream.Write(new CustomVertex.PositionNormalTextured(
				a, normal, tX.Z, tX.Y
				));
			tX = Vector3.TransformCoordinate(b, m);
			stream.Write(new CustomVertex.PositionNormalTextured(
				b, normal, tX.Z, tX.Y
				));
			tX = Vector3.TransformCoordinate(c, m);
			stream.Write(new CustomVertex.PositionNormalTextured(
				c, normal, tX.Z, tX.Y
				));

			((VertexBuffer)(buf)).Unlock();
		}

		public override void Render()
		{
			if(engine.IsShadowRendering)
			{
				RenderShadow();
				return;
			}

		//	RenderShadow(); return;

			engine.Device.SetTexture(0, face);
			engine.Device.SetStreamSource(0, buffer, lock_index);
			engine.Device.VertexFormat = CustomVertex.PositionNormalTextured.Format;
			
			if(!notEffectedByLight)
			{
				for(int j = 1, t = 0; j <= n; j++)
				{
					engine.Device.DrawPrimitives(PrimitiveType.TriangleStrip, t, (j-1)*2 + 1);
					t += j*2 + 1;
				}
			} 
			else 
			{
				engine.Device.DrawPrimitives(PrimitiveType.TriangleStrip, count - 3, 1);
			}

			engine.Device.SetTexture(0, null);
		}

		public override void RenderShadow()
		{
			engine.RenderVolume(a, b, c);
			engine.RenderVolume(c, b, a);
		}
	}


}