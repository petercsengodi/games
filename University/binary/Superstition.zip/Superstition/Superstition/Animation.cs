using System.Xml;
using System.Drawing;
using System.Reflection;
using System.Collections;

using Microsoft.DirectX;

using GameLib;
using XmlDataBindig;

namespace Engine
{
	using Model;

	public class Animation
	{
		private int max_scenes;
		private AnimPart[] parts;
		private Engine engine;

		public int MaxScenes
		{
			get { return max_scenes; }
		}

		public Animation(Engine engine)
		{
			this.engine = engine;
		}

		public void Load(string file_name)
		{
			CModelData data = (CModelData)XmlHandler.Load(file_name);
			this.max_scenes = data.max_scenes;
			this.parts = new AnimPart[data.parts.Count];

			for(int i = 0; i < this.parts.Length; i++)
			{
				CPartData d = (CPartData)data.parts[i];
				this.parts[i].element = engine.GetMeshElement(
					d.mesh_file, EngineMeshFlags.None, Color.White);
				this.parts[i].worlds = d.model_transform;
				this.parts[i].center = d.center_point;
			}
			
		} // End of function Load

		public void Render(Vector3 position, Vector3 direction, int scene)
		{
			Matrix m = Matrix.LookAtLH(position,
				position + direction, new Vector3(0f, 1f, 0f));
			m.Invert();
			Draw(m, scene);
		}

		public void Draw(Matrix common_world, int scene)
		{
			if(scene < 0 || scene >= max_scenes) return;
			Matrix actual;
			Matrix old = engine.Device.Transform.World;
			foreach(AnimPart part in parts)
			{
				actual = part.worlds[scene] * 
					Matrix.Translation(part.center[scene]) * 
					common_world;
				part.element.Render(actual);
			}

			engine.Device.Transform.World = old;
		}

	} // End of class Animation

	struct AnimPart
	{
		public MeshElement element;
		public Vector3[] center;
		public Matrix[] worlds;
	}

	class AnimID
	{
		public string file_name;
		public Animation anim;
	}

	public sealed class AnimationLibrary : Library
	{
		public static AnimationLibrary create(Engine engine)
		{
			return new AnimationLibrary(engine);
		}

		private AnimationLibrary(Engine engine) : base(engine)
		{
		}

		public Animation getAnimation(string file_name)
		{
			AnimID id = null;

			foreach(AnimID aid in library)
			{
				if(aid.file_name.Equals(file_name))
				{
					id = aid;
					break;
				}
			}

			if(id == null)
			{
				id = new AnimID();
				id.file_name = file_name;
				id.anim = engine.GetAnimation(file_name);
			}

			return id.anim;
		}

		public override void Clear()
		{
			library.Clear();
		}

	} // End of class AnimLibrary



}