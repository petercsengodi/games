using System;
using System.Drawing;
using System.Collections;
using Microsoft.DirectX;

namespace Engine
{

	/// <summary>
	/// Class for Renderable Elements constructed by primitives.
	/// </summary>
	public abstract class Element : IDisposable
	{
		protected Engine engine;
		private static Vector3 vup = new Vector3(0f, 1f, 0f);
		protected bool shadow = true;
		protected Matrix inverz = Matrix.Identity;

		/// <summary>
		/// Turn on/off element shadow. (True as default.)
		/// </summary>
		public bool Shadow
		{
			get{ return shadow; }
			set{ shadow = value; }
		}

		/// <summary>
		/// Class for Renderable Elements.
		/// </summary>
		/// <param name="_device">Device used by DirectX Engine.</param>
		public Element(Engine _engine)
		{
			engine = _engine;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		/// <param name="position">Position of the Object in the World.</param>
		/// <param name="orientation">Orientation of the Oject in the World.</param>
		public void Render(Vector3 translation, Vector3 orientation)
		{
			Matrix world;
			inverz = Matrix.LookAtLH(translation, 
				Vector3.Add(translation, orientation), vup);
			world = inverz;
			world.Invert();
//			engine.Device.Transform.World = world;

			Render();

//			engine.Device.Transform.World = Matrix.Identity;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		/// <param name="world">World matrix for element.</param>
		public void Render(Matrix world)
		{
			inverz = world;
			inverz.Invert();
//			engine.Device.Transform.World = world;
			Render();
//			engine.Device.Transform.World = Matrix.Identity;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		/// <param name="translation">Translation Vector.</param>
		public void Render(Vector3 translation)
		{
//			engine.Device.Transform.World = Matrix.Translation(translation);
			inverz = Matrix.Translation(-translation);
			
			Render();

//			engine.Device.Transform.World = Matrix.Identity;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		/// <param name="translation">Position of the Object in the World.</param>
		/// <param name="xRotation">Rotation of the Object at Axis X in the World.</param>
		/// <param name="yRotation">Rotation of the Object at Axis Y in the World.</param>
		/// <param name="zRotation">Rotation of the Object at Axis Z in the World.</param>
		public void Render(Vector3 translation, float xRotation, float yRotation, float zRotation)
		{
//			engine.Device.Transform.World = 
//				Matrix.Multiply(Matrix.RotationX(xRotation),
//				Matrix.Multiply(Matrix.RotationY(yRotation),
//				Matrix.Multiply(Matrix.RotationZ(zRotation),
//				Matrix.Translation(translation))));

			inverz = Matrix.Multiply(Matrix.Translation(-translation),
				Matrix.Multiply(Matrix.RotationZ(-zRotation),
				Matrix.Multiply(Matrix.RotationY(-yRotation),
				Matrix.RotationX(-xRotation))));
			
			Render();

//			engine.Device.Transform.World = Matrix.Identity;
		}

		/// <summary>
		/// Rendering the element.
		/// </summary>
		public abstract void Render();

		/// <summary>
		/// Disposes this element. (Gets itself out of Engine's 
		/// dispose list)
		/// </summary>
		abstract public void Dispose();

	} // End of Element

	/// <summary>
	/// Class for meshes.
	/// </summary>
	public class MeshElement : Element
	{

		public MeshElement(Engine engine, TextureLibrary lib, string filename, bool shadow)
			: base(engine)
		{
		}

		public void SetAttrib(Color color)
		{
		}

		public override void Render()
		{
		}

		public override void Dispose()
		{
		}

		public float Radius()
		{
			float ret = 0f;
			return ret;
		}

		public Vector3[] Borders()
		{		
			Vector3[] corners = new Vector3[2];
			return corners;
		}

	} // End of class Mesh Element

	/// <summary>
	/// Class for text meshes. Sholud be used only for the menu.
	/// </summary>
	public class MeshText : Element
	{
		private float extrusion;
		private Vector3 center = new Vector3(0f, 0f, 0f);
		public Vector3 Center { get { return center; } }

		public MeshText(Engine engine, System.Drawing.Font font, string text, float deviation, float extrusion)
			: base(engine)
		{
			this.extrusion = extrusion;

//			for(int i = 0; i < metrics.Length; i++)
//			{
//				center.X += metrics[i].BlackBoxX;
//				center.Y = Math.Max(center.Y, metrics[i].BlackBoxY);
//			}
//			center.Z = -extrusion / 2f;
		}

		public override void Render()
		{
		}

		public override void Dispose()
		{
		}

	}


	/// <summary>
	/// Class for Renderable Primitives.
	/// </summary>
	public abstract class Primitive : Element
	{
		protected bool notEffectedByLight = false;
		public bool NotEffectedByLight{ get { return notEffectedByLight; } set { notEffectedByLight = value; }}
		public int Count{ get { return count; } }

		/// <summary>
		/// Constructor.
		/// </summary>
		/// <param name="device">Device used by DirectX Engine.</param>
		public Primitive(Engine engine) : base(engine)
		{
		}

		/// <summary>
		/// Recreating Primitive.
		/// </summary>
		public virtual void ReCreate()
		{
		}

		/// <summary>
		/// Initializing Primitive.
		/// </summary>
		/// <param name="buf">VertexBuffer.</param>
		/// <param name="ea">Not Used.</param>
		abstract public void Initialize(object buf, EventArgs ea);

		/// <summary>
		/// ReInitialization of Primitive.
		/// </summary>
		public virtual void ReInit(){ Initialize(buffer, null); }

		/// <summary>
		/// Dispose function.
		/// </summary>
		public override void Dispose()
		{
		}

	} // End of Primitive


	/// <summary>
	/// Class for a tessellated Plane with faces of six directions.
	/// </summary>
	public class EPlane : Primitive
	{
		protected Vector3 Min, Max;
		protected StaticVectorLibrary.Direction direction;
		protected int x, y, z;
		
		public StaticVectorLibrary.Direction Direction
		{
			get{ return direction; }
		}

		public EPlane(Engine engine, Vector3 MinVec, Vector3 MaxVec, 
			StaticVectorLibrary.Direction _direction) : base(engine)
		{
		}
									   

		public override void Initialize(object buf, EventArgs ea)
		{
		}

		public override void Render()
		{
		}

	}

	/// <summary>
	/// A Triangle that's tesselated, keeping the culling.
	/// </summary>
	public class ETesselatedTriangle : Primitive
	{
		private Vector3 a, b, c, normal;
		private float lAB, lAC, lBC;
		private int n;

		public ETesselatedTriangle(Engine engine, Vector3 a, Vector3 b, Vector3 c) : base(engine)
		{
			this.a = a;
			this.b = b;
			this.c = c;
			Construct();
		}

		private void Construct()
		{
		}

		public override void Initialize(object buf, EventArgs ea)
		{
		}

		public override void Render()
		{
		}

	}


}