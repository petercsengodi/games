// Everything that's about to be used
using System;
using System.Drawing;
using System.Threading;
using System.Collections;
using System.Windows.Forms;

using Microsoft.DirectX;
using DInput = Microsoft.DirectX.DirectInput;

// Namespace of the Engine
namespace Engine
{
	using Superstition;
	using StateControl;

	/// <summary>
	/// Engine for Managed DirectX 3D.
	/// Has the functionality of the graphical presentation.
	///
	/// Controlled by the main application.
	/// </summary>
	public class Engine : IPeriod
	{
		// General attributes
		protected Form main = null; // Reference of the main window
		private bool alive = false; // Engine intited and functional - used by Threads

		// Attributes for shadow volume algorithms
		private bool isShadowRendering = false;
		private bool isLighted = false;

		// Engine Options
		protected EngineOptions options = new EngineOptions();
		public EngineOptions Options { get { return options; } }

		// State Controlling
		protected StateControl state;
		public StateControl State { get { return state; } }

		/// <summary>
		/// Is Engine Alive?
		/// </summary>
		public bool Alive { get { return alive; } }

		/// <summary>
		/// Get or set Light Position for Shadow Volume
		/// </summary>
		public Vector3 LightPosition
		{
			get{ return light; }
			set{ light = value; }
		}

		/// <summary>
		/// True, if shadow is to be rendered
		/// </summary>
		public bool IsShadowRendering { get{ return isShadowRendering; } }

		/// <summary>
		/// True, if map should be lighted
		/// </summary>
		public bool IsLighted { get{ return isLighted; } }

		// Lights
		private int NumberOfLights = 0;
		private Light[] lights;

		// Texture Library
		protected TextureLibrary library = null;

		// For Disposing
		protected ArrayList DisposeList = null;

		// Input Control
		private DInput.Device KeyDevice, MouseDevice;
		private AutoResetEvent MouseFire = null, KeyFire = null; // Synchronisation for Event Handler Threads
		private int bn_left, bn_right, bn_middle; // previous mouse button states

		/// <summary>
		/// Engine Pre-Intitialization.
		/// Only variable initialization.
		/// </summary>
		public Engine(Form Main, bool windowed)
		{
			MainFrame.WriteConsole("Engine Constructor - Software Engined");
			
			DisposeList = new ArrayList(0);
			main = Main; // Saving reference
			options.windowed = true;
			state = new StateControl(this, Main);
		}

		/// <summary>
		/// Engine Initialization.
		/// </summary>
		/// <param name="Main">Main frame uses DirectX</param>
		/// <param name="_model">Model that uses the Engine</param>
		/// <param name="windowed">Is Windowed?</param>
		/// <returns>Success</returns>
		public bool Start()
		{
			MainFrame.WriteConsole("Starting Engine Initialization");
			
			#region Screen Device


			#endregion

			#region Keyboard Device Initialization

			// Direct KeyBoard
			try
			{
				KeyDevice = new DInput.Device(DInput.SystemGuid.Keyboard); // Input Device
				KeyFire = new AutoResetEvent(false); // For Thread Synchronization
				KeyDevice.SetEventNotification(KeyFire); // Thread should be activated because of an Event
				(new Thread(new ThreadStart(HandleKeyboard))).Start(); // Starting Handle Thread 
				if(options.windowed) KeyDevice.SetCooperativeLevel(main,  // If windowed
										 DInput.CooperativeLevelFlags.NonExclusive |   //          not Exclusive
										 DInput.CooperativeLevelFlags.Background);     //          not Foreground
				else KeyDevice.SetCooperativeLevel(main, 
						 DInput.CooperativeLevelFlags.Exclusive |
						 DInput.CooperativeLevelFlags.Foreground);
				KeyDevice.Properties.BufferSize = 8; // Enough? Too much? Buffer is read very repeatative
				KeyDevice.Acquire();
				MainFrame.WriteConsole("Keyboard Inited.");
			}
			catch(DInput.InputException exception)
			{
				state.trigger(false); // Close();
				MainFrame.WriteConsole("FAILURE: " + exception.Message); // Report
				return false; // Do not start application
			}

			#endregion

			#region Mouse Device Initialization

			// Direct Mouse
			try
			{
				MouseDevice = new DInput.Device(DInput.SystemGuid.Mouse); // Device
				MouseFire = new AutoResetEvent(false); // For Thread Synchronization
				(new Thread(new ThreadStart(HandleMouse))).Start(); // Starting Handle Thread
				if(options.windowed) MouseDevice.SetCooperativeLevel(main, // If windowed
										 DInput.CooperativeLevelFlags.NonExclusive |    //    not Exclusive
										 DInput.CooperativeLevelFlags.Background);      //    not Foreground
				else MouseDevice.SetCooperativeLevel(main,
						 DInput.CooperativeLevelFlags.Exclusive |
						 DInput.CooperativeLevelFlags.Foreground);
				MouseDevice.SetEventNotification(MouseFire); // Setting Eventhandler
				MouseDevice.Acquire(); // Here?
				MainFrame.WriteConsole("Mouse Inited.");
			}
			catch(DInput.InputException exception)
			{
				state.trigger(false); // Close();
				MainFrame.WriteConsole("FAILURE: " + exception.Message); // Report
				return false; // Do not start application
			}

			#endregion

			#region Other Initializations

			// Other Initializations
			library = new TextureLibrary(device);
			StaticVectorLibrary.StaticInitializer();
			alive = true; // Needed for good thread functionality
			state.trigger(true);

			return alive; // Success

			#endregion
		}

		/// <summary>
		/// Function that runs if Device is reset.
		/// </summary>
		/// <param name="sender">Reference for Device.</param>
		/// <param name="ea">Arguments, not used.</param>
		private void OnDeviceReset(object sender, EventArgs ea)
		{
		}

		/// <summary>
		/// Initializing Variables for Rendering;
		/// </summary>
		private void RenderInitializing()
		{
			lights = new Light[8]; for(int i = 0; i < 8; i++) lights[i] = null;
		}

		/// <summary>
		/// Adds object to Engine's Disposable List, so element will be disposed,
		/// when Engine's closed.
		/// </summary>
		/// <param name="disp">Disposable Object</param>
		public void AddToDisposeList(IDisposable disp)
		{
			DisposeList.Add(disp);
		}

		/// <summary>
		/// Remove object from Engine's Disposable List.
		/// </summary>
		/// <param name="disp">Registered Disposable Object</param>
		public void RemoveFromDisposeList(IDisposable disp)
		{
			DisposeList.Remove(disp);
		}

		/// <summary>
		/// Clears the dispose list.
		/// </summary>
		public void ClearDisposeList()
		{
			foreach(object o in DisposeList)
			{
				IDisposable disposable = o as IDisposable;
				disposable.Dispose();
			}

			DisposeList.Clear();
		}

		/// <summary>
		/// Closing the Engine. It is careful with half-intialized datas.
		/// </summary>
		public void Close()
		{
			alive = false; // Threads should stop
			#region Close Keyboard Device

			if(KeyDevice != null)
			{ // Closing Keyboard Handling and used Thread
				if(KeyFire != null) KeyFire.Set(); // Thread notifies that Engine stopped
				KeyDevice.Unacquire(); // Release Keyboard
				KeyDevice.Dispose();
				KeyDevice = null;
			}

			#endregion

			#region Close Mouse Device

			if(MouseDevice != null)
			{ // Closing Mouse Handling and used Thread
				if(MouseFire != null) MouseFire.Set(); // Thread notifies that Engine stopped
				MouseDevice.Unacquire(); // Release Mouse
				MouseDevice.Dispose();
				MouseDevice = null;
			}

			#endregion

			#region Dispose Other Things

			// Other Destructions
			if(library != null) library.Dispose();
			library = null;

			if(fpsFont != null)
			{
				fpsFont.Dispose();
				fpsFont = null;
			}

			// Dispose Shadow Volume buffer
			if(volume != null)
			{
				volume.Dispose();
				volume = null;
			}

			if(shadowEffect != null)
			{
				shadowEffect.Dispose();
				shadowEffect = null;
			}

			if(DisposeList.Count > 0)
			{
				foreach(object o in DisposeList)
				{
					(o as IDisposable).Dispose();
					//					GC.SuppressFinalize(null);
				}
				DisposeList.Clear();
			}

			#endregion

			MainFrame.WriteConsole("Engine Closed.");
		}

		/// <summary>
		/// Mouse Handling Thread Function.
		/// Locks Model.
		/// </summary>
		private void HandleMouse()
		{
			MainFrame.WriteConsole("Mouse Handle Thread Started");

			#region Mouse Handling

			while(alive)
			{
				MouseFire.WaitOne(-1, false); // Waiting for an Event

				if(MouseDevice == null) continue;
				try{ MouseDevice.Poll(); } // Needs polling
				catch(DInput.InputException){ continue; }
				catch(System.NullReferenceException) { break; } // G���Z
				DInput.MouseState state;
				try{ state = MouseDevice.CurrentMouseState;} // Reading Mouse State
				catch(System.NullReferenceException) { break; } // G���Z
				byte[] buttons = state.GetMouseButtons();

				if(this.state.Model == null) continue; 

				Monitor.Enter(this); // Allocating Engine

				if(buttons[0] != bn_left) // Checking Left Mouse Button
				{
					if(bn_left == 0) this.state.Model.OnButtonDown(0);
					else this.state.Model.OnButtonUp(0);
					bn_left = buttons[0];
				}

				if(buttons[1] != bn_right) // Checking Right Mouse Button
				{
					if(bn_right == 0) this.state.Model.OnButtonDown(1);
					else this.state.Model.OnButtonUp(1);
					bn_right = buttons[1];
				}

				if(buttons[2] != bn_middle) // Checking Middle Mouse Button
				{
					if(bn_middle == 0) this.state.Model.OnButtonDown(2);
					else this.state.Model.OnButtonUp(2);
					bn_middle = buttons[2];
				}

				if((state.X != 0) || (state.Y != 0)) this.state.Model.OnMovement(state.X, state.Y);
				// Checking Mouse Movement

				Monitor.Exit(this); // Releasing Model
				
				//				WriteConsole("MouseEvent");
			}
			
			#endregion

			MainFrame.WriteConsole("Mouse Handle Thread Closed.");
		}

		/// <summary>
		/// Keyboard Handling Thread Function.
		/// Locks Model.
		/// </summary>
		private void HandleKeyboard()
		{
			MainFrame.WriteConsole("Keyboard Handle Thread Started");

			#region Keyboard Handling

			while(alive)
			{			
				KeyFire.WaitOne(-1, false); // Waiting for an Event

				if(KeyDevice == null) continue;
				DInput.BufferedDataCollection buffer = null;

				try
				{ // Reading Keyboard Buffer
					buffer = KeyDevice.GetBufferedData();
				}
				catch(DInput.InputException /*exception*/)
				{ // Handling Direct Input Exceptions - Not Perfect

					//					WriteConsole(exception.ToString());

					bool TryToAcquire = true;
					do
					{
						try{ KeyDevice.Acquire(); /* */ TryToAcquire = false; }
						catch(DInput.InputLostException){}
						catch(DInput.OtherApplicationHasPriorityException){ return;}
						catch(DInput.NotAcquiredException){ return;}
						catch(DInput.InputException){ return;}
						catch(System.NullReferenceException){ break; } // G���Z
					} while (TryToAcquire);
				}

				if(buffer == null) continue;
				if(state.Model == null) continue;

				Monitor.Enter(this); // Allocating Engine
				foreach(DInput.BufferedData data in buffer)
				{
					// Char Code: data.Offset
					// Up: data.Data & 0x80 == 0
					// Down: data.Data & 0x80 != 0
				
					// Simple Quit: data.Offset == 1 (?)
					//					if(data.Offset == 1) // Statemachine Changes must be created with Thread.
					//						(new Thread(new ThreadStart(main.Close))).Start();

					if((data.Data & 0x80) == 0) state.Model.OnKeyUp(data.Offset);
					else state.Model.OnKeyDown(data.Offset); // Redirecting to Model
				}

				Monitor.Exit(this);
			}

			#endregion

			MainFrame.WriteConsole("Keyboard Handle Thread Closed.");
		}

		/// <summary>
		/// Creates a Tessellated Plane Primitive.
		/// </summary>
		/// <param name="Left">First corner in vector.</param>
		/// <param name="Right">Last corner in vector.</param>
		/// <param name="direction">Direction of its face.</param>
		/// <param name="face">Texture.</param>
		/// <returns>Plane Primitve.</returns>
		public Primitive Pr_Plane(Vector3 Left, Vector3 Right,
			StaticVectorLibrary.Direction direction, string face)
		{
			return new EPlane(this, Vector3.Minimize(Left, Right),
				Vector3.Maximize(Left, Right), direction, library.getTexture(face));
		}

		/// <summary>
		/// Creates a Tessellated Triangle Primitive
		/// </summary>
		/// <param name="a">A vector</param>
		/// <param name="b">B vector</param>
		/// <param name="c">C vector</param>
		/// <param name="face">Texture name</param>
		/// <returns>Triangle Primitive</returns>
		public Primitive Pr_TesselatedTriangle(Vector3 a, Vector3 b, Vector3 c, string face)
		{
			return new ETesselatedTriangle(this, a, b, c, library.getTexture(face));
		}

		/// <summary>
		/// Creates a Mesh from File.
		/// </summary>
		/// <param name="filename">File Name.</param>
		/// <returns>Mesh Element.</returns>
		public MeshElement GetMeshElement(string filename, EngineMeshFlags flag, Color color)
		{
			MeshElement ret = null;
			if((flag & EngineMeshFlags.NoShadow) > 0)
				ret =  new MeshElement(this, library, filename, false);
			else ret =  new MeshElement(this, library, filename, true);
			if((flag & EngineMeshFlags.Colored) > 0)
				ret.SetAttrib(color);
			return ret;
		}

		/// <summary>
		/// Gets a Mesh from a text.
		/// </summary>
		/// <param name="font">Text font.</param>
		/// <param name="text">Text string.</param>
		/// <param name="deviation">Bending of text.</param>
		/// <param name="extrusion">Width of text.</param>
		/// <returns>Mesh element from the Text.</returns>
		public MeshText GetTextMesh(System.Drawing.Font font, string text, float deviation, float extrusion)
		{
			return new MeshText(this, font, text, deviation, extrusion);
		}

		/// <summary>
		/// Gives a Point Light.
		/// </summary>
		/// <param name="range">Range of light</param>
		/// <param name="color">Color of light.</param>
		/// <param name="position">Position of light.</param>
		/// <returns>Light reference. null if failed.</returns>
		public PointLight GetPointLight(float range, Color color, Vector3 position)
		{
			return new PointLight(this, range, color, position);
		}

		/// <summary>
		/// Gives a Directed Light.
		/// </summary>
		/// <param name="color">Color of light.</param>
		/// <param name="direction">Direction of light.</param>
		/// <returns>Light reference. null if failed.</returns>
		public DirectedLight GetDirectedLight(Color color, Vector3 direction)
		{
			return new DirectedLight(this, color, direction);
		}

		/// <summary>
		/// Register a light. Used by Class Light.
		/// </summary>
		/// <param name="light">Light reference.</param>
		/// <returns>Index.</returns>
		public int RegisterLight(Light light)
		{
			if(NumberOfLights > 7) return -1;
			
			for(int i = 0; i < 8; i++)
			{
				if(lights[i] == null)
				{
					lights[i] = light;
					NumberOfLights++;
					return i;
				}
			}

			return -1;
		}

		/// <summary>
		/// Unregister a light.
		/// </summary>
		/// <param name="light">Light reference.</param>
		/// <param name="index">Index of light.</param>
		/// <returns>Success.</returns>
		public bool UnRegisterLight(Light light, int index)
		{
			if(lights[index] == light)
			{
				lights[index] = null;
				NumberOfLights--;
				return true;
			} 
			else return false;
		}

		/// <summary>
		/// Renders.
		/// Locks Model.
		/// </summary>
		public void Render()
		{
			#region Initializing

			// Render Initialization
			//device.Clear(ClearFlags.Target | ClearFlags.ZBuffer | ClearFlags.Stencil, Color.Black, 1.0f, 0x20);

//			device.Transform.Projection = camera;

/*			state.Model.GetViewPosition; */
			

			#endregion

			Monitor.Enter(this);

			#region First Rendering: With Lights

			// First Rendering: With lights
			isLighted = true;
			isShadowRendering = false;
			state.Model.Render();
			isLighted = false;

			#endregion
			Monitor.Exit(this);

			for(int i = 0; i < 8; i++)
			{
				if(lights[i] != null) lights[i].DeActivate();
			}

			// Render Finishing
		}

		#region IPeriod Members

		public void Period()
		{
			if(state.Model != null) state.Model.Period();
		}

		#endregion

	} // End of Engine


	/// <summary>
	/// Class for engine options.
	/// </summary>
	public class EngineOptions
	{
		
		public bool renderShadow = false;
		public bool renderMeshShadow = false;
		public bool mapView = false;
		public bool windowed = true;
		public bool fpsView = true;

		public static float D_HIGH = 0.25f;
		public static float D_MID = 0.5f;
		public static float D_LOW = 1f;
		public float detail = D_LOW;

	}

	/// <summary>
	/// Model interface that this Engine can handle.
	/// </summary>
	public interface IModel : IPeriod, IDisposable
	{
		/// <summary>
		/// Doing Initialization Functionalities.
		/// </summary>
		void Initialize(Engine _engine);

		/// <summary>
		/// Graphical Rendering.
		/// </summary>
		void Render();

		/// <summary>
		/// Get View Position for Rendering.
		/// </summary>
		/// <returns>View Position.</returns>
		Vector3 GetViewPosition();

		/// <summary>
		/// Get View Direction for Rendering.
		/// </summary>
		/// <returns>View Direction.</returns>
		Vector3 GetViewDirection();

		/// <summary>
		/// Handling event, when a Key is pressed.
		/// </summary>
		/// <param name="key">Pressed Key's Code.</param>
		void OnKeyDown(int key);

		/// <summary>
		/// Handling event, when a Key is released.
		/// </summary>
		/// <param name="key">Released Key's Code.</param>
		void OnKeyUp(int key);

		/// <summary>
		/// Handling event, when a Mouse Button is pressed.
		/// </summary>
		/// <param name="button">0 = Left, 1 = Right, 2 = Middle</param>
		void OnButtonDown(int button);

		/// <summary>
		/// Handling event, when a Mouse Button is released.
		/// </summary>
		/// <param name="button">0 = Left, 1 = Right, 2 = Middle</param>
		void OnButtonUp(int button);

		/// <summary>
		/// Handling Mouse Movement Event.
		/// </summary>
		/// <param name="x">X Movement.</param>
		/// <param name="y">Y Movement.</param>
		void OnMovement(int x, int y);

		/// <summary>
		/// Gets model's Ambient light
		/// </summary>
		/// <returns>Ambient light in Color format</returns>
		Color GetAmbient();
	
	} // End of IModel

	/// <summary>
	/// Interface for classes, who does a Periodic Functionality.
	/// </summary>
	public interface IPeriod
	{
		/// <summary>
		/// Periodic Functionality.
		/// </summary>
		void Period();
	}

	public class StaticVectorLibrary
	{
		static public bool inited = false;

		public class Direction
		{

		}

		static public Direction Left = null, Right = null, Front = null,
			Back = null, Top = null, Bottom = null;

		/// <summary>
		/// Initializing statical Vector3 variables.
		/// </summary>
		static public void StaticInitializer()
		{
			if(inited) return; else inited = true;

			Left = new Direction();
			Right = new Direction();
			Front = new Direction();
			Back = new Direction();
			Top = new Direction();
			Bottom = new Direction();
		}

	}


} // End of NameSpace
