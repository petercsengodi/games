using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Drawing;
using System.Net;

namespace StateControl
{
	using Engine;
	using Menu;
	using Model;
	using GameLib;
	using Superstition;

	public delegate void Action();

	public class StateControl
	{
		private State state;
		public IModel Model { get { return state.Model; } }

		public StateControl(Engine engine, Form main)
		{
			state = new Initial_State(engine, main);
			if(state != null) state.enter();
		}

		public void trigger(object Object)
		{
			if(state == null) return;
			State new_state = state.trigger(Object);
			if(!new_state.Equals(state))
			{
				if(state != null) state.exit();
				state = new_state;
				if(state != null) state.enter();
			} 
			else 
			{
				if(state != null) state.stay();
			}
		}
	} // End of class State Control

	abstract class State
	{
		public IModel model;
		public IModel Model { get { return model; } }

		public Action entryAction, exitAction, innerAction;

		public State()
		{
			// Default initialization
			model = new JunkModel();
			entryAction = null;
			exitAction = null;
			innerAction = null;
		}

		public virtual State trigger(object Object)
		{
			if(Object == null) Object = "<null>";
			MainFrame.WriteConsole("> Trigger of " + 
				this.ToString() + " : " + Object.ToString());
			return this;
		}

		public virtual void enter()
		{
			MainFrame.WriteConsole("> Entering " + this.ToString());
			if(entryAction != null) entryAction();
		}

		public virtual void exit()
		{
			MainFrame.WriteConsole("> Exiting " + this.ToString());
			if(exitAction != null) exitAction();
		}

		public virtual void stay()
		{
			MainFrame.WriteConsole("> Staying " + this.ToString());
			if(innerAction != null) innerAction();
		}

	} // End of base class State

	class Play_State : State
	{
		protected GameMenu_State menu;

		public Play_State(Engine engine, Model model)
		{
			this.model = model; 
		}

		public void setGameMenu(GameMenu_State menu)
		{
			this.menu = menu;
		}

		public override State trigger(object Object)
		{
			base.trigger(Object);
			return menu;
		}

	} // End of Play State

	class Load_State : State
	{
		protected Play_State play;
		protected IModel gameModel;
		protected Engine engine;

		public Load_State(Engine engine, IModel gameModel)
		{
			this.engine = engine;
			this.gameModel = gameModel;
			model = new LoadingTitle();
			model.Initialize(engine);
		}

		public void setPlayState(Play_State play)
		{
			this.play = play;
		}

		public override State trigger(object Object)
		{
			return play;
		}


	} // End of Load State

	class MainMenu_State : State
	{
		protected Quit_State quit;
		protected Play_State play;
		protected Load_State load;
		protected Engine engine;
		protected Model gameModel;
		protected string filename;
		protected Network.NetHost host;
		protected HostData host_data;
		protected UserInfo user;
		protected MapBuffer map;
		protected IPAddress address;
		
		public MainMenu_State(Engine engine, Model gameModel, Quit_State quit, 
			Play_State play, Load_State load)
		{
			this.quit = quit;
			this.play = play;
			this.load = load;
			this.engine = engine;
			this.gameModel = gameModel;
		}

		public override State trigger(object Object)
		{
			base.trigger(Object);
			
			TriggerParams selection = (TriggerParams)Object;
			switch(selection.command)
			{
				case MainMenuSelection.LOAD_MAP:
					filename = selection.StringParameter;
					(new Thread(new ThreadStart(loading))).Start();
					return load;

				case MainMenuSelection.LOAD_GAME:
					filename = selection.StringParameter;
					(new Thread(new ThreadStart(loadgame))).Start();
					return load;

				case MainMenuSelection.DENSE_MAP:
					(new Thread(new ThreadStart(densemap))).Start();
					return load;

				case MainMenuSelection.JOIN_HOST:
					object[] array = (object[])selection.ObjectParameter;
					host = (Network.NetHost)array[0];
					address = (IPAddress)array[1];
					host_data = (HostData)array[2];
					user = (UserInfo)array[3];
					map = (MapBuffer)array[4];
					(new Thread(new ThreadStart(joinhost))).Start();
					return load;

				case MainMenuSelection.SAVE_GAME:
					return this;

				case MainMenuSelection.QUIT:
					return quit;
			}

			return this;
		}

		public override void enter()
		{
			base.enter();
			model = new MainMenu(engine);
			model.Initialize(engine);
		}


		public override void exit()
		{
			base.exit ();
			model.Dispose();
		}

		private void loading()
		{
			gameModel.LoadXmlMap(filename);
			gameModel.Initialize(engine);
			Thread.CurrentThread.Abort();
		}

		private void joinhost()
		{
			gameModel.SetDataModel(
				ModelIO.ExtractModelData(map.map_buffer));
			gameModel.Initialize(engine);

			Network.PlayClient play_client = new Network.PlayClient(
				address, user.game_port, user.client_port, user.userID);
			gameModel.StartNetworkPlay(play_client, (int)user.userID);

			host = null;
			address = null;
			host_data = null;
			user = null;
			map = null;
			Thread.CurrentThread.Abort();
		}

		private void loadgame()
		{
			ModelIO.LoadModelFromFile(gameModel, filename);
			gameModel.Initialize(engine);
			Thread.CurrentThread.Abort();
		}

		private void densemap()
		{
			gameModel.DenseMap();
			gameModel.Initialize(engine);
			Thread.CurrentThread.Abort();
		}

	} // End of Main Menu State

	class GameMenu_State : State
	{
		protected Quit_State quit;
		protected Play_State play;
		protected Load_State load;
		protected Engine engine;
		protected Model gameModel;
		protected string filename;
		protected Network.NetHost host;
		protected IPAddress address;
		protected HostData host_data;
		protected UserInfo user;
		protected MapBuffer map;
		
		public GameMenu_State(Engine engine, Model gameModel, Quit_State quit, 
			Play_State play, Load_State load)
		{
			this.quit = quit;
			this.play = play;
			this.load = load;
			this.engine = engine;
			this.gameModel = gameModel;
		}

		public override State trigger(object Object)
		{
			base.trigger(Object);
			
			TriggerParams selection = (TriggerParams)Object;
			switch(selection.command)
			{
				case MainMenuSelection.LOAD_MAP:
					filename = selection.StringParameter;
					(new Thread(new ThreadStart(loading))).Start();
					return load;

				case MainMenuSelection.LOAD_GAME:
					filename = selection.StringParameter;
					(new Thread(new ThreadStart(loadgame))).Start();
					return load;

				case MainMenuSelection.DENSE_MAP:
					(new Thread(new ThreadStart(densemap))).Start();
					return load;

				case MainMenuSelection.JOIN_HOST:
					object[] array = (object[])selection.ObjectParameter;
					host = (Network.NetHost)array[0];
					address = (IPAddress)array[1];
					host_data = (HostData)array[2];
					user = (UserInfo)array[3];
					map = (MapBuffer)array[4];
					(new Thread(new ThreadStart(joinhost))).Start();
					return load;

				case MainMenuSelection.PUBLISH_HOST:
					object[] array2 = (object[])selection.ObjectParameter;
					host = (Network.NetHost)array2[0];
					address = (IPAddress)array2[1];
					host_data = (HostData)array2[2];
					user = (UserInfo)array2[3];
					publishhost();
					return play;

				case MainMenuSelection.SAVE_GAME:
					filename = selection.StringParameter;
					ModelIO.SaveModelToFile(gameModel, filename);
					return play;

				case MainMenuSelection.QUIT:
					gameModel.Dispose();
					return quit;
			}

			return play;
		}

		public override void enter()
		{
			base.enter();
			model = new MainMenu(engine, true, gameModel);
			model.Initialize(engine);
		}


		public override void exit()
		{
			base.exit();
			model.Dispose();
		}

		private void loading()
		{
			gameModel.Dispose();
			gameModel.LoadXmlMap(filename);
			gameModel.Initialize(engine);
			host = null;
			host_data = null;
			user = null;
			map = null;
			Thread.CurrentThread.Abort();
		}

		private void joinhost()
		{
			gameModel.Dispose();
			gameModel.SetDataModel(
				ModelIO.ExtractModelData(map.map_buffer));
			gameModel.Initialize(engine);
			
			Network.PlayClient play_client = new Network.PlayClient(
				address, user.game_port, user.client_port, user.userID);
			gameModel.StartNetworkPlay(play_client, (int)user.userID);

			host = null;
			address = null;
			host_data = null;
			user = null;
			map = null;

			Thread.CurrentThread.Abort();
		}

		private void publishhost()
		{
			Network.PlayClient play_client = new Network.PlayClient(
				address, user.game_port, user.client_port, user.userID);
			gameModel.StartNetworkPlay(play_client, (int)user.userID);

			host = null;
			address = null;
			host_data = null;
			user = null;
			map = null;

//			Thread.CurrentThread.Abort();
		}

		private void loadgame()
		{
			gameModel.Dispose();
			ModelIO.LoadModelFromFile(gameModel, filename);
			gameModel.Initialize(engine);
			Thread.CurrentThread.Abort();
		}

		private void densemap()
		{
			gameModel.Dispose();
			gameModel.DenseMap();
			gameModel.Initialize(engine);
			Thread.CurrentThread.Abort();
		}


	} // End of Game Menu State

	class Initial_State : State
	{
		public Engine engine;
		public Quit_State quit;
		
		public Initial_State(Engine engine, Form main)
		{
			this.engine = engine;
			quit = new Quit_State(main);
		}

		public override State trigger(object Object)
		{
			base.trigger(Object);
			
			if(Object.Equals(false)) return quit;
			Model gameModel = new Model();
			Play_State play = new Play_State(engine, gameModel);
			Load_State loadState = new Load_State(engine, gameModel);
			GameMenu_State gameMenu = new GameMenu_State(engine, 
				gameModel, quit, play, loadState);
			MainMenu_State mainMenu = new MainMenu_State(engine,
				gameModel, quit, play, loadState);
			play.setGameMenu(gameMenu);
			loadState.setPlayState(play);
			return mainMenu;
		}

	} // End of Initial State

	class Quit_State : State
	{
		protected Form main;

		public Quit_State(Form main)
		{
			this.main = main;	
		}

		public override void enter()
		{
			base.enter();
			(new Thread(new ThreadStart(main.Close))).Start();
		}


	} // End of Quit State

	/// <summary>
	/// A model that does nothing
	/// </summary>
	public class JunkModel : IModel
	{
		#region IModel Members

		public void Initialize(Engine _engine)
		{
		}

		public void Render()
		{
		}

		public Microsoft.DirectX.Vector3 GetViewPosition()
		{
			return new Microsoft.DirectX.Vector3(0f, 0f, 0f);
		}

		public Microsoft.DirectX.Vector3 GetViewDirection()
		{
			return new Microsoft.DirectX.Vector3(0f, 0f, -3f);
		}

		public void OnKeyDown(int key)
		{
		}

		public void OnKeyUp(int key)
		{
		}

		public void OnButtonDown(int button)
		{
		}

		public void OnButtonUp(int button)
		{
		}

		public void OnMovement(int x, int y)
		{
		}

		public Color GetAmbient()
		{
			return Color.FromArgb(20, 20, 20);
		}

		public void Dispose()
		{
		}

		#endregion

		#region IPeriod Members

		public void Period()
		{
			// TODO:  Add JunkModel.Period implementation
		}

		#endregion

	}

}